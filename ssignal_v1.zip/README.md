# S Signal App
Floating "S" overlay that reads the on-screen chart and shows RSI + MACD + EMA based CALL / PUT / WAIT estimates.
Probability-based analysis only - never a guaranteed signal.
