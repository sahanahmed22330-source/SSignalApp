# Sahan Ai Elite
Selective signals: gives CALL/PUT only when the best-performing logic, the indicators and a second logic agree; otherwise WAIT.
Backtest numbers are past-candle scores, not win probabilities. Real win rate is tracked in the RESULTS tab.
