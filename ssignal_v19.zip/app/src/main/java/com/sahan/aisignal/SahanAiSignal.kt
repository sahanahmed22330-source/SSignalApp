/*
 * SAHAN AI SMART  -  মার্কেট কোন লজিকে চলছে তা নিজে খুঁজে সিগন্যাল দেয় (একটি ফাইল, Kotlin)
 *
 *  নতুন: ১১টা লজিক (Trend, Reversion, Streak, Fade, Wick, Pattern, Breakout, Bounce, MACD, ZigZag, Combo)
 *  চার্টের আগের ক্যান্ডেলগুলোতে প্রতিটা লজিক কতবার ঠিক ছিল তা মিলিয়ে দেখে (ব্যাকটেস্ট),
 *  এখন যে লজিক সবচেয়ে ভালো চলছে সেই লজিকে সিগন্যাল দেয়; লজিক ভুল হতে থাকলে অন্য লজিকে চলে যায়।
 *  নিজের ট্রেডের ফলাফল (WIN/LOSS) থেকেও প্রতিটা লজিকের নম্বর ঠিক করে।
 *
 * ---- নিচে আগের Sahan Ai Signal এর বর্ণনা ----
 * SAHAN AI SIGNAL  -  শক্তিশালী লাইভ চার্ট অ্যানালাইজার (একটি ফাইল, Kotlin)
 *
 *  - S/AI বাটন Quotex চার্টের উপর বসিয়ে ট্যাপ করলে ৩-৪ সেকেন্ড লাইভ স্ক্যান করে CALL/PUT সিগন্যাল দেয়
 *  - ক্যান্ডেলের মুভমেন্ট, সাইজ, উপর-নিচের উইক, প্যাটার্ন (engulfing, hammer, star ...), ট্রেন্ড,
 *    RSI, MACD, Bollinger, Stochastic, সাপোর্ট/রেজিস্ট্যান্স ও টার্গেট একসাথে মিলিয়ে বিশ্লেষণ করে
 *  - Quotex এর টাইমার (trade time) ও ক্যান্ডেলের কাউন্টডাউন OCR দিয়ে নিজে পড়ে (AUTO টাইম)
 *  - BUY / SELL বাটন নিজে চিনে নেয় (CALIBRATE লাগে না)
 *  - AUTO SIGNAL / AUTO ENTRY আলাদা আলাদা অন-অফ, AUTO ENTRY এর কোনো সীমা নেই
 *  - ফলাফল (WIN / LOSS / DRAW) নিজে হিসাব করে জমা রাখে, ভুল হলে হাতে ঠিক করা যায়
 *
 * সিগন্যাল শুধু বিশ্লেষণ-ভিত্তিক আনুমানিক ধারণা, জেতার নিশ্চয়তা নয়।
 */
package com.sahan.aisignal

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileDescriptor
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.tanh

/* =============================================================================
 *  MODELS
 * ========================================================================== */

data class Candle(
    val open: Double, val high: Double, val low: Double, val close: Double, val x: Float
) {
    val bullish get() = close > open
}

enum class Direction { CALL, PUT }

data class AiSignal(
    val direction: Direction,
    val confidence: Int,        // সিগন্যালের শক্তি % (৫০ = দুর্বল, বেশি = শক্ত)
    val grade: String,          // STRONG / MEDIUM / WEAK
    val reasons: String,        // কেন এই সিগন্যাল
    val candleCount: Int,
    val score: Double,
    val logic: String = "",        // কোন লজিকে সিগন্যাল
    val logicInfo: String = "",    // লজিকের রেকর্ড (যেমন Trend 11/14)
    val explain: String = "",      // আগের ক্যান্ডেল কোন কারণে আপ/ডাউন
    val wait: Boolean = false,     // true হলে সিগন্যাল নেই (WAIT)
    val backtest: String = "",     // আগের ক্যান্ডেলে ঠিক বলার রেকর্ড, যেমন 9/10 (90%)
    val levels: List<LevelInfo> = emptyList(),   // চার্টে দেখানোর লেভেল
    val forced: Boolean = false   // WAIT সীমার কারণে জোর করে দেওয়া দুর্বল সিগন্যাল
)

/** kind: "R" রেজিস্ট্যান্স, "S" সাপোর্ট, "RN" রাউন্ড লেভেল; p = ক্যান্ডেল-দামের এককে */
data class LevelInfo(val p: Double, val kind: String, val touches: Int)

/** result: PENDING, WIN, LOSS, DRAW, UNKNOWN.  entry/exit = 0.0 মানে পড়া যায়নি */
data class HistoryEntry(
    val id: Long, val dir: String, val conf: Int, val tf: Int,
    var entry: Double, var exit: Double, var result: String,
    val auto: Boolean, var fixed: Boolean,
    val logic: String = ""
)

private fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/* =============================================================================
 *  HISTORY STORE  (ফলাফল জমা)
 * ========================================================================== */

object HistoryStore {
    private const val KEY = "history"
    private val lock = Any()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("sahan_ai", Context.MODE_PRIVATE)

    fun load(ctx: Context): MutableList<HistoryEntry> = synchronized(lock) {
        val out = ArrayList<HistoryEntry>()
        try {
            val arr = JSONArray(prefs(ctx).getString(KEY, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    HistoryEntry(
                        o.getLong("id"), o.getString("dir"), o.getInt("conf"), o.getInt("tf"),
                        o.getDouble("entry"), o.getDouble("exit"), o.getString("result"),
                        o.getBoolean("auto"), o.getBoolean("fixed"), o.optString("logic", "")
                    )
                )
            }
        } catch (_: Exception) {
        }
        out
    }

    private fun write(ctx: Context, list: List<HistoryEntry>) {
        val arr = JSONArray()
        for (e in list.takeLast(300)) {
            arr.put(
                JSONObject().put("id", e.id).put("dir", e.dir).put("conf", e.conf).put("tf", e.tf)
                    .put("entry", e.entry).put("exit", e.exit).put("result", e.result)
                    .put("auto", e.auto).put("fixed", e.fixed).put("logic", e.logic)
            )
        }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    fun add(ctx: Context, e: HistoryEntry) {
        synchronized(lock) {
            val l = load(ctx)
            l.add(e)
            write(ctx, l)
        }
    }

    fun update(ctx: Context, id: Long, block: (HistoryEntry) -> Unit) {
        synchronized(lock) {
            val l = load(ctx)
            val e = l.firstOrNull { it.id == id } ?: return
            block(e)
            write(ctx, l)
        }
    }

    fun clear(ctx: Context) {
        synchronized(lock) { prefs(ctx).edit().remove(KEY).apply() }
    }
}

/* =============================================================================
 *  INDICATORS  (EMA, RSI, MACD)
 * ========================================================================== */

object Indicators {

    fun ema(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val k = 2.0 / (period + 1)
        val out = ArrayList<Double>(values.size)
        var prev = values[0]
        out.add(prev)
        for (i in 1 until values.size) {
            prev = values[i] * k + prev * (1 - k)
            out.add(prev)
        }
        return out
    }

    /** Wilder RSI. রিটার্ন লিস্টের দৈর্ঘ্য = closes.size - period */
    fun rsi(closes: List<Double>, period: Int = 14): List<Double> {
        if (closes.size <= period) return emptyList()
        var gain = 0.0
        var loss = 0.0
        for (i in 1..period) {
            val d = closes[i] - closes[i - 1]
            if (d >= 0) gain += d else loss -= d
        }
        var avgGain = gain / period
        var avgLoss = loss / period
        val out = ArrayList<Double>()
        fun value(): Double =
            if (avgLoss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + avgGain / avgLoss)
        out.add(value())
        for (i in period + 1 until closes.size) {
            val d = closes[i] - closes[i - 1]
            val g = max(d, 0.0)
            val l = max(-d, 0.0)
            avgGain = (avgGain * (period - 1) + g) / period
            avgLoss = (avgLoss * (period - 1) + l) / period
            out.add(value())
        }
        return out
    }

    data class Macd(val line: List<Double>, val signal: List<Double>, val hist: List<Double>)

    fun macd(closes: List<Double>, fast: Int = 12, slow: Int = 26, signalP: Int = 9): Macd {
        val ef = ema(closes, fast)
        val es = ema(closes, slow)
        val line = closes.indices.map { ef[it] - es[it] }
        val sig = ema(line, signalP)
        val hist = line.indices.map { line[it] - sig[it] }
        return Macd(line, sig, hist)
    }
}

/* =============================================================================
 *  CHART READER  (স্ক্রিনশট থেকে ক্যান্ডেল, চার্ট এলাকা ও BUY/SELL বাটন)
 * ========================================================================== */

object ChartReader {

    private const val MIN_PIXELS = 6
    private const val MIN_WIDTH = 3

    fun isGreen(r: Int, g: Int, b: Int) = g > 130 && g > r + 55 && g > b + 50
    fun isRed(r: Int, g: Int, b: Int) = r > 165 && r > g + 75 && r > b + 65

    /** BUY/SELL বাটনের ব্যান্ড [উপরের y, নিচের y]; না পেলে null */
    fun findBand(bmp: Bitmap): IntArray? {
        val w = bmp.width
        val h = bmp.height
        val row = IntArray(w)
        var y = (h * 0.80f).toInt()
        var start = -1
        var end = -1
        var run = 0
        while (y < h) {
            bmp.getPixels(row, 0, w, 0, y, w, 1)
            var cnt = 0
            var samples = 0
            var x = 0
            while (x < w) {
                val p = row[x]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                if (isGreen(r, g, b) || isRed(r, g, b)) cnt++
                samples++
                x += 3
            }
            if (cnt >= samples * 0.40) {
                if (start < 0) start = y
                run++
                end = y
            } else {
                if (start >= 0 && run >= 8) break
                start = -1; run = 0
            }
            y += 2
        }
        return if (start >= 0 && run >= 8) intArrayOf(start, end) else null
    }

    /** চার্ট এলাকা: উপরে হেডারের নিচ থেকে, নিচে BUY/SELL প্যানেলের উপর পর্যন্ত */
    fun autoRegion(bmp: Bitmap): Pair<Int, Int> {
        val h = bmp.height
        val top = (h * 0.12f).toInt()
        var bottom = (h * 0.70f).toInt()
        val band = findBand(bmp)
        if (band != null) {
            bottom = (band[0] - h * 0.155f).toInt().coerceIn((h * 0.50f).toInt(), (h * 0.85f).toInt())
        }
        return top to bottom
    }

    /** BUY (সবুজ) ও SELL (লাল) বাটনের মাঝখান: [buyX, buyY, sellX, sellY]; না পেলে null */
    fun findButtons(bmp: Bitmap): FloatArray? {
        val band = findBand(bmp) ?: return null
        val w = bmp.width
        val row = IntArray(w)
        var gMinX = Int.MAX_VALUE; var gMaxX = -1; var gMinY = Int.MAX_VALUE; var gMaxY = -1
        var rMinX = Int.MAX_VALUE; var rMaxX = -1; var rMinY = Int.MAX_VALUE; var rMaxY = -1
        var y = band[0]
        while (y <= band[1]) {
            bmp.getPixels(row, 0, w, 0, y, w, 1)
            var x = 0
            while (x < w) {
                val p = row[x]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                if (isGreen(r, g, b)) {
                    if (x < gMinX) gMinX = x; if (x > gMaxX) gMaxX = x
                    if (y < gMinY) gMinY = y; if (y > gMaxY) gMaxY = y
                } else if (isRed(r, g, b)) {
                    if (x < rMinX) rMinX = x; if (x > rMaxX) rMaxX = x
                    if (y < rMinY) rMinY = y; if (y > rMaxY) rMaxY = y
                }
                x += 2
            }
            y += 2
        }
        if (gMaxX < 0 || rMaxX < 0) return null
        return floatArrayOf((gMinX + gMaxX) / 2f, (gMinY + gMaxY) / 2f, (rMinX + rMaxX) / 2f, (rMinY + rMaxY) / 2f)
    }

    /** ল্যান্ডস্কেপ: ডানের প্যানেলে BUY (সবুজ) ও SELL (লাল) বাটনের মাঝখান */
    fun findButtonsLand(bmp: Bitmap): FloatArray? {
        val w = bmp.width
        val h = bmp.height
        val x0 = (w * 0.79f).toInt()
        val y0 = (h * 0.45f).toInt()
        val y1 = (h * 0.97f).toInt()
        val ww = w - x0
        if (ww <= 0 || y0 >= y1) return null
        val row = IntArray(ww)
        var gMinX = Int.MAX_VALUE; var gMaxX = -1; var gMinY = Int.MAX_VALUE; var gMaxY = -1
        var rMinX = Int.MAX_VALUE; var rMaxX = -1; var rMinY = Int.MAX_VALUE; var rMaxY = -1
        var y = y0
        while (y < y1) {
            bmp.getPixels(row, 0, ww, x0, y, ww, 1)
            var x = 0
            while (x < ww) {
                val p = row[x]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                val ax = x + x0
                if (isGreen(r, g, b)) {
                    if (ax < gMinX) gMinX = ax; if (ax > gMaxX) gMaxX = ax
                    if (y < gMinY) gMinY = y; if (y > gMaxY) gMaxY = y
                } else if (isRed(r, g, b)) {
                    if (ax < rMinX) rMinX = ax; if (ax > rMaxX) rMaxX = ax
                    if (y < rMinY) rMinY = y; if (y > rMaxY) rMaxY = y
                }
                x += 2
            }
            y += 2
        }
        if (gMaxX < 0 || rMaxX < 0) return null
        return floatArrayOf((gMinX + gMaxX) / 2f, (gMinY + gMaxY) / 2f, (rMinX + rMaxX) / 2f, (rMinY + rMaxY) / 2f)
    }

    /** [regionTop, regionBottom) এলাকায় ক্যান্ডেল খোঁজে। প্রাইস = (এলাকার উচ্চতা - y) */
    fun detect(bmp: Bitmap, regionTop: Int, regionBottom: Int, left: Int = 0, right: Int = bmp.width): List<Candle> {
        val w = right - left
        val h = regionBottom - regionTop
        if (h <= 10) return emptyList()
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, left, regionTop, w, h)

        val type = IntArray(w)
        val colMin = IntArray(w) { Int.MAX_VALUE }
        val colMax = IntArray(w) { -1 }

        for (x in 0 until w) {
            var gc = 0; var gMin = Int.MAX_VALUE; var gMax = -1
            var rc = 0; var rMin = Int.MAX_VALUE; var rMax = -1
            for (y in 0 until h) {
                val p = px[y * w + x]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                if (isGreen(r, g, b)) {
                    gc++; if (y < gMin) gMin = y; if (y > gMax) gMax = y
                } else if (isRed(r, g, b)) {
                    rc++; if (y < rMin) rMin = y; if (y > rMax) rMax = y
                }
            }
            if (gc >= MIN_PIXELS && gc >= rc) {
                type[x] = 1; colMin[x] = gMin; colMax[x] = gMax
            } else if (rc >= MIN_PIXELS) {
                type[x] = 2; colMin[x] = rMin; colMax[x] = rMax
            }
        }

        val candles = ArrayList<Candle>()
        var x = 0
        while (x < w) {
            if (type[x] == 0) { x++; continue }
            val t = type[x]
            var end = x
            while (end + 1 < w && type[end + 1] == t) end++
            val width = end - x + 1
            if (width >= MIN_WIDTH && width <= w / 5) {
                val mins = ArrayList<Int>()
                val maxs = ArrayList<Int>()
                var hi = Int.MAX_VALUE
                var lo = -1
                for (cx in x..end) {
                    mins.add(colMin[cx]); maxs.add(colMax[cx])
                    if (colMin[cx] < hi) hi = colMin[cx]
                    if (colMax[cx] > lo) lo = colMax[cx]
                }
                mins.sort(); maxs.sort()
                val bodyTop = mins[mins.size / 2]
                val bodyBottom = maxs[maxs.size / 2]
                fun price(yy: Int) = (h - yy).toDouble()
                val open: Double
                val close: Double
                if (t == 1) { open = price(bodyBottom); close = price(bodyTop) }
                else { open = price(bodyTop); close = price(bodyBottom) }
                candles.add(Candle(open, price(hi), price(lo), close, (x + end) / 2f))
            }
            x = end + 1
        }
        return candles
    }
}

/* =============================================================================
 *  OCR  (Quotex এর টাইমার, ক্যান্ডেল কাউন্টডাউন ও বর্তমান প্রাইস পড়া)
 * ========================================================================== */

object Ocr {

    class Line(val text: String, val rect: Rect)

    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    /** bmp এর crop অংশে লেখা পড়ে; ব্যর্থ হলে খালি লিস্ট (ব্যাকগ্রাউন্ড থ্রেডে ডাকতে হবে) */
    fun read(bmp: Bitmap, crop: Rect): List<Line> {
        return try {
            val l = crop.left.coerceIn(0, bmp.width - 1)
            val t = crop.top.coerceIn(0, bmp.height - 1)
            val r = crop.right.coerceIn(l + 1, bmp.width)
            val b = crop.bottom.coerceIn(t + 1, bmp.height)
            val piece = Bitmap.createBitmap(bmp, l, t, r - l, b - t)
            val text = Tasks.await(recognizer.process(InputImage.fromBitmap(piece, 0)), 4, TimeUnit.SECONDS)
            val out = ArrayList<Line>()
            for (block in text.textBlocks) {
                for (line in block.lines) {
                    val rc = line.boundingBox ?: continue
                    out.add(Line(line.text, Rect(rc.left + l, rc.top + t, rc.right + l, rc.bottom + t)))
                }
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private val rxExpiry = Regex("""(\d{1,2}):(\d{2}):(\d{2})""")
    private val rxCount = Regex("""^\d{2}:\d{2}$""")
    private val rxPrice = Regex("""\d{1,6}[.,]\d{2,6}""")

    /** Quotex এর "Timer 00:01:00" থেকে সেকেন্ড */
    fun parseExpirySeconds(lines: List<Line>): Int? {
        for (l in lines) {
            val m = rxExpiry.find(l.text.replace(" ", "")) ?: continue
            val h = m.groupValues[1].toIntOrNull() ?: continue
            val mi = m.groupValues[2].toIntOrNull() ?: continue
            val s = m.groupValues[3].toIntOrNull() ?: continue
            val total = h * 3600 + mi * 60 + s
            if (total in 1..3600) return total
        }
        return null
    }

    /** চার্টের ডানদিকের "00:13" ধরনের ক্যান্ডেল কাউন্টডাউন (বাকি সেকেন্ড) */
    fun parseCountdown(lines: List<Line>, width: Int): Int? {
        for (l in lines) {
            if (l.rect.left < width * 0.40f) continue
            val t = l.text.trim().replace(" ", "")
            if (!rxCount.matches(t)) continue
            val mm = t.substring(0, 2).toIntOrNull() ?: continue
            val ss = t.substring(3, 5).toIntOrNull() ?: continue
            if (ss > 59) continue
            return mm * 60 + ss
        }
        return null
    }

    private fun isBlue(bmp: Bitmap, x: Int, y: Int): Boolean {
        if (x < 0 || y < 0 || x >= bmp.width || y >= bmp.height) return false
        val p = bmp.getPixel(x, y)
        val r = (p shr 16) and 255
        val g = (p shr 8) and 255
        val b = p and 255
        return b > 170 && r < 125 && g in 85..205
    }

    /** বর্তমান প্রাইস ও তার পিলের জায়গা */
    fun findPriceRect(bmp: Bitmap, lines: List<Line>): Pair<Double, Rect>? {
        for (l in lines) {
            val m = rxPrice.find(l.text.replace(" ", "")) ?: continue
            val rc = l.rect
            val midY = rc.centerY()
            var hits = 0
            if (isBlue(bmp, rc.left - 5, midY)) hits++
            if (isBlue(bmp, rc.right + 5, midY)) hits++
            if (isBlue(bmp, rc.centerX(), rc.top - 3)) hits++
            if (isBlue(bmp, rc.centerX(), rc.bottom + 3)) hits++
            if (hits >= 2) {
                val v = m.value.replace(',', '.').toDoubleOrNull()
                if (v != null) return v to rc
            }
        }
        return null
    }

    fun findPrice(bmp: Bitmap, lines: List<Line>): Double? = findPriceRect(bmp, lines)?.first

    /** চার্টের ডানের দামের লেবেলগুলো (গ্রিড লাইনের রাউন্ড লেভেল): (y, লেখা) */
    fun axisLabels(bmp: Bitmap, lines: List<Line>, exclude: Rect?): List<Pair<Int, String>> {
        val out = ArrayList<Pair<Int, String>>()
        for (l in lines) {
            val t = l.text.replace(" ", "")
            val m = rxPrice.find(t) ?: continue
            if (m.value.length != t.length) continue
            if (l.rect.left < bmp.width * 0.72f) continue
            if (exclude != null && Rect.intersects(exclude, l.rect)) continue
            out.add(l.rect.centerY() to m.value)
        }
        return out
    }

    /** প্রাইস পিলের ঠিক বাঁ পাশের "00:13" ধরনের ক্যান্ডেল কাউন্টডাউন (উপরের "End of trade 01:04" নয়) */
    fun parseCountdownNear(lines: List<Line>, price: Rect?): Int? {
        if (price == null) return null
        for (l in lines) {
            val t = l.text.trim().replace(" ", "")
            if (!rxCount.matches(t)) continue
            val rc = l.rect
            if (abs(rc.centerY() - price.centerY()) > price.height()) continue
            if (rc.right > price.left + 10) continue
            if (price.left - rc.right > price.width()) continue
            val mm = t.substring(0, 2).toIntOrNull() ?: continue
            val ss = t.substring(3, 5).toIntOrNull() ?: continue
            if (ss > 59) continue
            return mm * 60 + ss
        }
        return null
    }
}

/* =============================================================================
 *  GEO  (ফোন সোজা বা আড়াআড়ি, দুই অবস্থায় চার্ট/বাটন/টাইমারের জায়গা)
 * ========================================================================== */

object Geo {
    fun land(b: Bitmap) = b.width > b.height

    /** চার্ট এলাকা [বাম, উপর, ডান, নিচ] */
    fun chart(b: Bitmap): IntArray {
        val w = b.width
        val h = b.height
        if (land(b)) {
            return intArrayOf((w * 0.06f).toInt(), (h * 0.335f).toInt(), (w * 0.795f).toInt(), (h * 0.945f).toInt())
        }
        val r = ChartReader.autoRegion(b)
        return intArrayOf(0, r.first, w, r.second)
    }

    /** প্রাইস পিল ও তার পাশের কাউন্টডাউন যে অংশে থাকে */
    fun priceCrop(b: Bitmap): Rect {
        val w = b.width
        val h = b.height
        return if (land(b)) Rect((w * 0.50f).toInt(), (h * 0.22f).toInt(), (w * 0.82f).toInt(), (h * 0.97f).toInt())
        else Rect((w * 0.40f).toInt(), (h * 0.12f).toInt(), w, (h * 0.80f).toInt())
    }

    /** Quotex এর Timer/Time ঘর */
    fun expiryCrop(b: Bitmap): Rect {
        val w = b.width
        val h = b.height
        return if (land(b)) Rect((w * 0.79f).toInt(), (h * 0.16f).toInt(), w, (h * 0.52f).toInt())
        else Rect(0, (h * 0.72f).toInt(), (w * 0.65f).toInt(), (h * 0.90f).toInt())
    }

    /** BUY/SELL বাটনের মাঝখান [buyX, buyY, sellX, sellY]; না পেলে স্ক্রিনের মাপ অনুযায়ী ধরে নেয় */
    fun buttons(b: Bitmap): FloatArray {
        val w = b.width.toFloat()
        val h = b.height.toFloat()
        return if (land(b)) {
            ChartReader.findButtonsLand(b) ?: floatArrayOf(w * 0.9007f, h * 0.714f, w * 0.9007f, h * 0.853f)
        } else {
            ChartReader.findButtons(b) ?: floatArrayOf(w * 0.257f, h * 0.914f, w * 0.743f, h * 0.914f)
        }
    }

    /** স্ক্যান লাইনের ওঠানামার সীমা [উপর, নিচ] */
    fun sweep(b: Bitmap, chartBottom: Int): Pair<Int, Int> {
        val h = b.height
        return if (land(b)) (h * 0.267f).toInt() to chartBottom
        else (h * 0.093f).toInt() to min(chartBottom, (h * 0.70f).toInt())
    }
}

/* =============================================================================
 *  AI ENGINE  (ক্যান্ডেল, উইক, সাইজ, প্যাটার্ন, ট্রেন্ড, RSI, MACD, Bollinger, Stochastic, S/R)
 * ========================================================================== */

object AiEngine {

    private fun linSlope(v: List<Double>): Double {
        val n = v.size
        if (n < 2) return 0.0
        val mx = (n - 1) / 2.0
        val my = v.average()
        var num = 0.0
        var den = 0.0
        for (i in 0 until n) {
            num += (i - mx) * (v[i] - my)
            den += (i - mx) * (i - mx)
        }
        return if (den == 0.0) 0.0 else num / den
    }

    private fun body(x: Candle) = abs(x.close - x.open)
    private fun upW(x: Candle) = x.high - max(x.open, x.close)
    private fun loW(x: Candle) = min(x.open, x.close) - x.low
    private fun rng(x: Candle) = max(x.high - x.low, 1.0)

    /**
     * c = বাঁ থেকে ডানে ক্যান্ডেল (শেষটা চলমান), liveDelta = ৩-৪ সেকেন্ডে চলমান ক্যান্ডেলের close এর পরিবর্তন,
     * ফলাফল সবসময় CALL বা PUT; শক্তি বোঝায় confidence % আর grade।
     */
    fun analyze(c: List<Candle>, liveDelta: Double, tfSec: Int): AiSignal {
        val n = c.size
        val closes = c.map { it.close }
        val atrN = min(14, n)
        val atr = max(c.takeLast(atrN).map { it.high - it.low }.average(), 1.0)
        val hi = c.maxOf { it.high }
        val lo = c.minOf { it.low }
        val last = closes.last()
        val a = c[n - 1]
        val b = c[n - 2]
        val p = c[n - 3]

        val votes = ArrayList<Pair<Double, String>>()
        fun vote(v: Double, why: String) {
            if (v != 0.0) votes.add(v to why)
        }

        val quick = n < 30

        // ---- ১) ট্রেন্ড: EMA + রিগ্রেশন স্লোপ ----
        val emaF = Indicators.ema(closes, if (quick) 5 else 9).last()
        val emaS = Indicators.ema(closes, if (quick) 13 else 21).last()
        val slopeAtr = linSlope(closes.takeLast(min(10, n))) / atr
        val trendV = when {
            emaF > emaS && slopeAtr > 0.05 -> 2.0
            emaF > emaS -> 1.0
            emaF < emaS && slopeAtr < -0.05 -> -2.0
            emaF < emaS -> -1.0
            else -> 0.0
        }
        vote(trendV, if (trendV > 0) "Trend up" else "Trend down")

        // ---- ২) RSI ----
        val rsiList = Indicators.rsi(closes, if (quick) 7 else 14)
        if (rsiList.size >= 2) {
            val rsi = rsiList.last()
            val rsiPrev = rsiList[rsiList.size - 2]
            val rv = when {
                rsi < 30 -> 2.0
                rsi > 70 -> -2.0
                rsi < 45 && rsi > rsiPrev -> 1.0
                rsi > 55 && rsi < rsiPrev -> -1.0
                rsi in 50.0..70.0 && rsi >= rsiPrev -> 1.0
                rsi in 30.0..50.0 && rsi <= rsiPrev -> -1.0
                else -> 0.0
            }
            vote(rv, if (rv > 0) "RSI ${rsi.toInt()} bullish" else "RSI ${rsi.toInt()} bearish")
        }

        // ---- ৩) MACD ----
        val mc = if (quick) Indicators.macd(closes, 5, 13, 4) else Indicators.macd(closes, 12, 26, 9)
        val hist = mc.hist.last()
        val histPrev = mc.hist[mc.hist.size - 2]
        val mv = when {
            histPrev <= 0 && hist > 0 -> 2.0
            histPrev >= 0 && hist < 0 -> -2.0
            hist > 0 && hist > histPrev -> 1.0
            hist < 0 && hist < histPrev -> -1.0
            hist < 0 && hist > histPrev -> 0.5
            hist > 0 && hist < histPrev -> -0.5
            else -> 0.0
        }
        vote(mv, if (mv > 0) "MACD up" else "MACD down")

        // ---- ৪) Bollinger Band ----
        val bp = min(14, n)
        val win = closes.takeLast(bp)
        val mean = win.average()
        var varSum = 0.0
        for (v in win) varSum += (v - mean) * (v - mean)
        val sd = Math.sqrt(varSum / bp)
        if (sd > 0.0) {
            val upper = mean + 2 * sd
            val lower = mean - 2 * sd
            val pb = (last - lower) / (upper - lower)
            val prevClose = closes[n - 2]
            when {
                last < lower && last > prevClose -> vote(1.0, "Bounce from lower band")
                last > upper && last < prevClose -> vote(-1.0, "Rejected at upper band")
                pb < 0.1 -> vote(0.5, "Near lower band")
                pb > 0.9 -> vote(-0.5, "Near upper band")
            }
        }

        // ---- ৫) Stochastic ----
        val kP = min(8, n - 4)
        fun kAt(i: Int): Double {
            var hh = -1e18
            var ll = 1e18
            for (j in (i - kP + 1)..i) {
                hh = max(hh, c[j].high)
                ll = min(ll, c[j].low)
            }
            return if (hh - ll <= 0.0) 50.0 else (c[i].close - ll) / (hh - ll) * 100.0
        }
        if (kP >= 3) {
            val k0 = kAt(n - 1); val k1 = kAt(n - 2); val k2 = kAt(n - 3); val k3 = kAt(n - 4)
            val d0 = (k0 + k1 + k2) / 3.0
            val d1 = (k1 + k2 + k3) / 3.0
            if (k1 < d1 && k0 > d0 && k0 < 35) vote(1.0, "Stochastic cross up")
            if (k1 > d1 && k0 < d0 && k0 > 65) vote(-1.0, "Stochastic cross down")
        }

        // ---- ৬) ক্যান্ডেল প্যাটার্ন ----
        val aB = body(a)
        val bB = body(b)
        val before = closes[max(0, n - 5)]
        val downBefore = closes[n - 2] < before
        val upBefore = closes[n - 2] > before
        if (!b.bullish && a.bullish && a.open <= b.close && a.close >= b.open && aB > bB) vote(2.0, "Bullish engulfing")
        if (b.bullish && !a.bullish && a.open >= b.close && a.close <= b.open && aB > bB) vote(-2.0, "Bearish engulfing")
        if (aB > 0 && loW(a) >= 2 * aB && upW(a) <= max(aB * 0.5, rng(a) * 0.15) && downBefore) vote(2.0, "Hammer")
        else if (loW(a) >= 0.6 * rng(a) && downBefore) vote(1.5, "Bottom rejection (pin bar)")
        if (aB > 0 && upW(a) >= 2 * aB && loW(a) <= max(aB * 0.5, rng(a) * 0.15) && upBefore) vote(-2.0, "Shooting star")
        else if (upW(a) >= 0.6 * rng(a) && upBefore) vote(-1.5, "Top rejection (pin bar)")
        if (!p.bullish && body(p) > atr * 0.8 && bB < body(p) * 0.4 && a.bullish && a.close > (p.open + p.close) / 2) vote(2.0, "Morning star")
        if (p.bullish && body(p) > atr * 0.8 && bB < body(p) * 0.4 && !a.bullish && a.close < (p.open + p.close) / 2) vote(-2.0, "Evening star")
        if (a.bullish && b.bullish && p.bullish && a.close > b.close && b.close > p.close) vote(1.5, "Three white soldiers")
        if (!a.bullish && !b.bullish && !p.bullish && a.close < b.close && b.close < p.close) vote(-1.5, "Three black crows")
        val doji = aB <= 0.1 * rng(a)

        // ---- ৭) উইক চাপ (শেষ ৩ ক্যান্ডেল) ----
        var wp = 0.0
        for (x in c.takeLast(3)) wp += (loW(x) - upW(x)) / rng(x)
        wp /= 3.0
        if (wp > 0.25) vote(1.0, "Lower wick rejection")
        else if (wp < -0.25) vote(-1.0, "Upper wick rejection")

        // ---- ৮) ক্যান্ডেলের সাইজ ও মোমেন্টাম ----
        val br = aB / atr
        val exhausted = br > 2.6
        if (br > 1.2 && !exhausted) {
            val w = if (aB >= 0.8 * rng(a)) 1.5 else 1.0
            vote(if (a.bullish) w else -w, if (a.bullish) "Strong bullish candle" else "Strong bearish candle")
        }

        // ---- ৯) সুইং স্ট্রাকচার, সাপোর্ট/রেজিস্ট্যান্স ও টার্গেট ----
        val pivH = ArrayList<Int>()
        val pivL = ArrayList<Int>()
        for (i in 2 until n - 2) {
            if (c[i].high >= c[i - 1].high && c[i].high >= c[i - 2].high &&
                c[i].high >= c[i + 1].high && c[i].high >= c[i + 2].high) pivH.add(i)
            if (c[i].low <= c[i - 1].low && c[i].low <= c[i - 2].low &&
                c[i].low <= c[i + 1].low && c[i].low <= c[i + 2].low) pivL.add(i)
        }
        var res = Double.MAX_VALUE
        for (i in pivH) if (c[i].high > last && c[i].high < res) res = c[i].high
        if (res == Double.MAX_VALUE) res = hi
        var sup = -Double.MAX_VALUE
        for (i in pivL) if (c[i].low < last && c[i].low > sup) sup = c[i].low
        if (sup == -Double.MAX_VALUE) sup = lo
        val dR = (res - last) / atr
        val dS = (last - sup) / atr
        if (dS < 0.6 && (a.bullish || loW(a) > aB * 0.5)) vote(1.0, "Near support")
        if (dR < 0.6 && (!a.bullish || upW(a) > aB * 0.5)) vote(-1.0, "Near resistance")
        val prevHigh = pivH.filter { it < n - 3 }.map { c[it].high }.maxOrNull()
        val prevLow = pivL.filter { it < n - 3 }.map { c[it].low }.minOrNull()
        if (prevHigh != null && last > prevHigh && a.bullish) vote(1.0, "Breakout up")
        if (prevLow != null && last < prevLow && !a.bullish) vote(-1.0, "Breakdown")
        if (pivH.size >= 2 && pivL.size >= 2) {
            val hh = c[pivH[pivH.size - 1]].high > c[pivH[pivH.size - 2]].high
            val hl = c[pivL[pivL.size - 1]].low > c[pivL[pivL.size - 2]].low
            if (hh && hl) vote(1.0, "Higher highs & lows")
            else if (!hh && !hl) vote(-1.0, "Lower highs & lows")
        }

        // ---- ১০) লাইভ মোমেন্টাম (৩-৪ সেকেন্ডের স্ক্যান) ----
        val lm = liveDelta / atr
        val liveV = when {
            lm > 0.35 -> 2.0
            lm > 0.12 -> 1.0
            lm < -0.35 -> -2.0
            lm < -0.12 -> -1.0
            else -> 0.0
        }
        vote(liveV, if (liveV > 0) "Live momentum up" else "Live momentum down")

        // ---- ফলাফল ----
        var pos = 0.0
        var neg = 0.0
        for (v in votes) if (v.first > 0) pos += v.first else neg -= v.first
        val score = pos - neg
        val dir = when {
            score > 0.0 -> Direction.CALL
            score < 0.0 -> Direction.PUT
            liveV != 0.0 -> if (liveV > 0) Direction.CALL else Direction.PUT
            trendV != 0.0 -> if (trendV > 0) Direction.CALL else Direction.PUT
            else -> if (a.bullish) Direction.CALL else Direction.PUT
        }
        val total = pos + neg
        val agreement = if (total == 0.0) 0.0 else abs(pos - neg) / total

        var pen = 0.0
        if (doji) pen += 3.0
        if (exhausted) pen += 4.0
        if (dir == Direction.CALL && dR < 0.3) pen += 4.0      // উপরে রেজিস্ট্যান্স খুব কাছে
        if (dir == Direction.PUT && dS < 0.3) pen += 4.0       // নিচে সাপোর্ট খুব কাছে

        val conf = (50.0 + 26.0 * tanh(abs(score) / 7.0) * (0.55 + 0.45 * agreement) - pen)
            .coerceIn(50.0, 80.0).toInt()
        val grade = when {
            conf >= 66 -> "STRONG"
            conf >= 58 -> "MEDIUM"
            else -> "WEAK"
        }

        val sign = if (dir == Direction.CALL) 1.0 else -1.0
        val why = votes.filter { it.first * sign > 0 }
            .sortedByDescending { abs(it.first) }
            .map { it.second }
            .distinct()
            .take(3)
        val reasons = if (why.isEmpty()) "Mixed signals" else why.joinToString(" • ")
        return AiSignal(dir, conf, grade, reasons, n, score)
    }
}


/* =============================================================================
 *  LEVELS  (সাপোর্ট/রেজিস্ট্যান্স: কতবার ছুঁয়েছে গুনে শক্ত লেভেল + গ্রিডের রাউন্ড লেভেল)
 * ========================================================================== */

object Levels {
    class Lv(var p: Double, var touches: Int, var round: Boolean)

    fun build(c: List<Candle>, atr: Double, rounds: List<Double>): List<Lv> {
        val tol = atr * 0.35
        val pts = ArrayList<Double>()
        for (i in 2 until c.size - 2) {
            if (c[i].high >= c[i - 1].high && c[i].high >= c[i - 2].high &&
                c[i].high >= c[i + 1].high && c[i].high >= c[i + 2].high) pts.add(c[i].high)
            if (c[i].low <= c[i - 1].low && c[i].low <= c[i - 2].low &&
                c[i].low <= c[i + 1].low && c[i].low <= c[i + 2].low) pts.add(c[i].low)
        }
        pts.sort()
        val out = ArrayList<Lv>()
        for (x in pts) {
            val cur = out.lastOrNull()
            if (cur != null && abs(x - cur.p) <= tol) {
                cur.p = (cur.p * cur.touches + x) / (cur.touches + 1)
                cur.touches++
            } else {
                out.add(Lv(x, 1, false))
            }
        }
        for (r in rounds) {
            val near = out.firstOrNull { abs(it.p - r) <= tol }
            if (near != null) {
                near.touches++
                near.round = true
            } else {
                out.add(Lv(r, 0, true))
            }
        }
        return out
    }
}

/* =============================================================================
 *  LOGIC ENGINE  (মার্কেট এখন কোন লজিকে চলছে তা খুঁজে সেই লজিকে সিগন্যাল)
 * ========================================================================== */

object LogicEngine {

    private class Strat(val name: String, val abbr: String, val fn: (List<Candle>) -> Int)

    private fun dirOf(x: Candle): Int = if (x.close > x.open) 1 else if (x.close < x.open) -1 else 0
    private fun bodyOf(x: Candle) = abs(x.close - x.open)
    private fun upWick(x: Candle) = x.high - max(x.open, x.close)
    private fun loWick(x: Candle) = min(x.open, x.close) - x.low
    private fun rangeOf(x: Candle) = max(x.high - x.low, 1.0)

    /** ট্রেন্ড: EMA ক্রম + দাম EMA এর ওপর/নিচে → ট্রেন্ডের দিকেই চলবে */
    private fun sTrend(p: List<Candle>): Int {
        if (p.size < 8) return 0
        val cl = p.map { it.close }
        val f = Indicators.ema(cl, 5).last()
        val s = Indicators.ema(cl, 13).last()
        val last = cl.last()
        return when {
            f > s && last > f -> 1
            f < s && last < f -> -1
            else -> 0
        }
    }

    /** রিভার্শন: RSI/Bollinger এর চরমে গেলে উল্টো দিকে ফিরবে */
    private fun sRevert(p: List<Candle>): Int {
        if (p.size < 8) return 0
        val cl = p.map { it.close }
        val rl = Indicators.rsi(cl, 7)
        if (rl.isEmpty()) return 0
        val rsi = rl.last()
        val w = cl.takeLast(10)
        val m = w.average()
        var v = 0.0
        for (x in w) v += (x - m) * (x - m)
        val sd = Math.sqrt(v / w.size)
        val last = cl.last()
        return when {
            rsi < 32 || (sd > 0 && last < m - 2 * sd) -> 1
            rsi > 68 || (sd > 0 && last > m + 2 * sd) -> -1
            else -> 0
        }
    }

    /** স্ট্রিক: পরপর দুই ক্যান্ডেল একই রঙ হলে সেই দিকেই চলবে */
    private fun sStreak(p: List<Candle>): Int {
        if (p.size < 3) return 0
        val a = dirOf(p[p.size - 1])
        val b = dirOf(p[p.size - 2])
        return if (a != 0 && a == b) a else 0
    }

    /** ফেড: পরপর তিন ক্যান্ডেল একই রঙ হলে উল্টো ফিরবে */
    private fun sFade(p: List<Candle>): Int {
        if (p.size < 4) return 0
        val a = dirOf(p[p.size - 1])
        val b = dirOf(p[p.size - 2])
        val c = dirOf(p[p.size - 3])
        return if (a != 0 && a == b && b == c) -a else 0
    }

    /** উইক: নিচে লম্বা উইক = কেনার চাপ, উপরে লম্বা উইক = বেচার চাপ */
    private fun sWick(p: List<Candle>): Int {
        val x = p.last()
        val r = rangeOf(x)
        val b = bodyOf(x)
        return when {
            loWick(x) >= 0.5 * r && loWick(x) >= 2 * b -> 1
            upWick(x) >= 0.5 * r && upWick(x) >= 2 * b -> -1
            else -> 0
        }
    }

    /** প্যাটার্ন: engulfing, morning/evening star */
    private fun sPattern(p: List<Candle>): Int {
        if (p.size < 3) return 0
        val n = p.size
        val a = p[n - 1]
        val b = p[n - 2]
        val q = p[n - 3]
        return when {
            dirOf(b) < 0 && dirOf(a) > 0 && a.open <= b.close && a.close >= b.open -> 1
            dirOf(b) > 0 && dirOf(a) < 0 && a.open >= b.close && a.close <= b.open -> -1
            dirOf(q) < 0 && bodyOf(b) < bodyOf(q) * 0.4 && dirOf(a) > 0 && a.close > (q.open + q.close) / 2 -> 1
            dirOf(q) > 0 && bodyOf(b) < bodyOf(q) * 0.4 && dirOf(a) < 0 && a.close < (q.open + q.close) / 2 -> -1
            else -> 0
        }
    }

    /** ব্রেকআউট: আগের ৮ ক্যান্ডেলের উচ্চ/নিম্ন ভাঙলে সেই দিকে চলবে */
    private fun sBreakout(p: List<Candle>): Int {
        if (p.size < 6) return 0
        val n = p.size
        val len = min(8, n - 1)
        var hh = -1e18
        var ll = 1e18
        for (j in (n - 1 - len) until (n - 1)) {
            hh = max(hh, p[j].high)
            ll = min(ll, p[j].low)
        }
        val last = p[n - 1].close
        return when {
            last > hh -> 1
            last < ll -> -1
            else -> 0
        }
    }

    /** বাউন্স: রেঞ্জের নিচে সাপোর্ট থেকে উঠবে, উপরে রেজিস্ট্যান্স থেকে নামবে */
    private fun sBounce(p: List<Candle>): Int {
        if (p.size < 6) return 0
        val w = p.takeLast(min(10, p.size))
        var hh = -1e18
        var ll = 1e18
        for (x in w) { hh = max(hh, x.high); ll = min(ll, x.low) }
        val pos = (p.last().close - ll) / max(hh - ll, 1.0)
        return when {
            pos < 0.15 -> 1
            pos > 0.85 -> -1
            else -> 0
        }
    }

    /** MACD: হিস্টোগ্রামের দিক ও গতি */
    private fun sMacd(p: List<Candle>): Int {
        if (p.size < 8) return 0
        val m = Indicators.macd(p.map { it.close }, 5, 13, 4)
        val h = m.hist.last()
        val hp = m.hist[m.hist.size - 2]
        return when {
            h > 0 && h >= hp -> 1
            h < 0 && h <= hp -> -1
            else -> 0
        }
    }

    /** জিগজ্যাগ: ক্যান্ডেল একটা সবুজ একটা লাল করে চললে পরেরটাও উল্টো হবে */
    private fun sZigzag(p: List<Candle>): Int {
        if (p.size < 4) return 0
        val a = dirOf(p[p.size - 1])
        val b = dirOf(p[p.size - 2])
        val c = dirOf(p[p.size - 3])
        return if (a != 0 && b != 0 && c != 0 && a == -b && b == -c) -a else 0
    }

    /** ট্রেন্ড+ব্রেকআউট (কড়া): EMA9>EMA21, ১০ ক্যান্ডেলের উচ্চ/নিম্ন ভাঙা, বডি ≥ 0.35 ATR, RSI সীমার ভেতর; বড় ক্যান্ডেলে ঢুকবে না */
    private fun sTrendBreak(p: List<Candle>): Int {
        if (p.size < 14) return 0
        val cl = p.map { it.close }
        val e9 = Indicators.ema(cl, 9).last()
        val e21 = Indicators.ema(cl, 21).last()
        val rl = Indicators.rsi(cl, if (p.size >= 30) 14 else 7)
        if (rl.isEmpty()) return 0
        val rsi = rl.last()
        var sum = 0.0
        var m = 0
        for (i in max(1, p.size - 14) until p.size) {
            sum += max(p[i].high - p[i].low, max(abs(p[i].high - p[i - 1].close), abs(p[i].low - p[i - 1].close)))
            m++
        }
        val atr = max(sum / m, 1.0)
        val prev = p.subList(max(0, p.size - 11), p.size - 1)
        val res = prev.maxOf { it.high }
        val sup = prev.minOf { it.low }
        val x = p.last()
        val body = bodyOf(x)
        if (x.high - x.low > atr * 1.8) return 0
        val up = e9 > e21 && x.close > e9
        val down = e9 < e21 && x.close < e9
        val bull = x.close > res && x.close > x.open && body >= atr * 0.35
        val bear = x.close < sup && x.close < x.open && body >= atr * 0.35
        return when {
            up && bull && rsi in 52.0..68.0 -> 1
            down && bear && rsi in 32.0..48.0 -> -1
            else -> 0
        }
    }

    /** পুলব্যাক: ট্রেন্ডে দাম EMA13 ছুঁয়ে ফের ট্রেন্ডের দিকে ক্যান্ডেল দিলে সেই দিকেই */
    private fun sPullback(p: List<Candle>): Int {
        if (p.size < 12) return 0
        val cl = p.map { it.close }
        val e5 = Indicators.ema(cl, 5)
        val e13 = Indicators.ema(cl, 13)
        val n = p.size
        var rs = 0.0
        for (x in p.takeLast(10)) rs += x.high - x.low
        val atr = max(rs / 10, 1.0)
        val x = p[n - 1]
        val upTrend = e5[n - 1] > e13[n - 1] && e13[n - 1] > e13[n - 4]
        val downTrend = e5[n - 1] < e13[n - 1] && e13[n - 1] < e13[n - 4]
        val touchedUp = min(p[n - 2].low, p[n - 3].low) <= e13[n - 1] + 0.25 * atr
        val touchedDn = max(p[n - 2].high, p[n - 3].high) >= e13[n - 1] - 0.25 * atr
        return when {
            upTrend && touchedUp && dirOf(x) > 0 && x.close > e5[n - 1] -> 1
            downTrend && touchedDn && dirOf(x) < 0 && x.close < e5[n - 1] -> -1
            else -> 0
        }
    }

    /** ইনসাইড বার: ছোট ক্যান্ডেল আগেরটার ভেতরে থাকার পর বড়টার উচ্চ/নিম্ন ভাঙলে সেই দিকে */
    private fun sInside(p: List<Candle>): Int {
        if (p.size < 5) return 0
        val n = p.size
        val m = p[n - 3]
        val i = p[n - 2]
        val x = p[n - 1]
        if (i.high > m.high || i.low < m.low) return 0
        return when {
            x.close > m.high -> 1
            x.close < m.low -> -1
            else -> 0
        }
    }

    /** কম্বো: সব ইন্ডিকেটরের মিলিত সিদ্ধান্ত (AiEngine) */
    private fun sCombo(p: List<Candle>): Int {
        if (p.size < 10) return 0
        return if (AiEngine.analyze(p, 0.0, 60).direction == Direction.CALL) 1 else -1
    }

    private val strats: List<Strat> = listOf(
        Strat("Trend", "TR") { sTrend(it) },
        Strat("Reversion", "RV") { sRevert(it) },
        Strat("Streak", "ST") { sStreak(it) },
        Strat("Fade", "FD") { sFade(it) },
        Strat("Wick", "WK") { sWick(it) },
        Strat("Pattern", "PT") { sPattern(it) },
        Strat("Breakout", "BO") { sBreakout(it) },
        Strat("Bounce", "BN") { sBounce(it) },
        Strat("MACD", "MC") { sMacd(it) },
        Strat("ZigZag", "ZZ") { sZigzag(it) },
        Strat("Pullback", "PB") { sPullback(it) },
        Strat("InsideBar", "IB") { sInside(it) },
        Strat("TrendBreak", "TB") { sTrendBreak(it) },
        Strat("Combo", "CB") { sCombo(it) }
    )

    /**
     * live = নিজের আগের ট্রেডের ফল: লজিকের নাম → (জয়, হার)
     * ধাপ: প্রতিটা লজিক আগের ক্যান্ডেলগুলোতে পরের ক্যান্ডেল কতবার ঠিক বলেছে (নতুন ক্যান্ডেলে বেশি ওজন)
     * → সবচেয়ে ভালো চলা লজিক বেছে সেই লজিকের এখনকার সিদ্ধান্ত।
     */
    fun analyze(c: List<Candle>, liveDelta: Double, tfSec: Int, live: Map<String, Pair<Int, Int>>, minAcc: Double, roundLevels: List<Double> = emptyList()): AiSignal {
        val base = AiEngine.analyze(c, liveDelta, tfSec)
        val n = c.size
        if (n < 12) return base.copy(wait = true, grade = "WAIT", logic = "-", logicInfo = "Too few candles", reasons = "Zoom out so more candles are visible")

        val k = strats.size
        val outcome = IntArray(n) { dirOf(c[it]) }
        val acc = DoubleArray(k)
        val cnt = IntArray(k)
        val hits = IntArray(k)
        val nowPred = IntArray(k)
        val hitAt = Array(k) { IntArray(n) }       // 1 = ঠিক, -1 = ভুল, 0 = বলেনি (লক্ষ্য ক্যান্ডেলের জায়গায়)

        // বাজার ট্রেন্ডে না রেঞ্জে: Efficiency Ratio (০ = এলোমেলো, ১ = সোজা চলা)
        val lookback = min(10, n - 1)
        var path = 0.0
        for (i in (n - lookback) until n) path += abs(c[i].close - c[i - 1].close)
        val er = if (path <= 0.0) 0.0 else abs(c[n - 1].close - c[n - 1 - lookback].close) / path
        val trendSet = setOf("Trend", "Breakout", "TrendBreak", "Streak", "MACD", "Pullback", "InsideBar")
        val rangeSet = setOf("Reversion", "Bounce", "Fade", "Wick", "ZigZag")

        for (si in 0 until k) {
            val st = strats[si]
            var wTot = 0.0
            var wHit = 0.0
            val seq = ArrayList<Boolean>()
            for (i in 7..(n - 2)) {
                val target = outcome[i + 1]
                if (target == 0) continue
                val pr = st.fn(c.subList(0, i + 1))
                if (pr == 0) continue
                val w = Math.pow(0.5, (n - 2 - i) / 6.0)
                wTot += w
                cnt[si]++
                if (pr == target) {
                    wHit += w; hits[si]++; hitAt[si][i + 1] = 1; seq.add(true)
                } else {
                    hitAt[si][i + 1] = -1; seq.add(false)
                }
            }
            val lw = live[st.name]
            val lWins = lw?.first ?: 0
            val lLoss = lw?.second ?: 0
            val prior = 3.0
            var a = (wHit + 0.5 * prior + lWins * 1.5) / (wTot + prior + (lWins + lLoss) * 1.5)
            val m = seq.size
            if (m >= 2 && !seq[m - 1] && !seq[m - 2]) a -= 0.04      // সদ্য পরপর দুবার ভুল হলে নম্বর কমে
            // বাজারের ধরনের সাথে মেলে এমন লজিকের নম্বর সামান্য বাড়ে, না মিললে কমে
            if (er > 0.40) {
                if (st.name in trendSet) a += 0.03 else if (st.name in rangeSet) a -= 0.03
            } else if (er < 0.25) {
                if (st.name in rangeSet) a += 0.03 else if (st.name in trendSet) a -= 0.03
            }
            acc[si] = a
            nowPred[si] = st.fn(c)
        }

        val order = (0 until k).filter { cnt[it] >= 4 }.sortedByDescending { acc[it] }
        var chosen = -1
        for (i in order) {
            if (nowPred[i] != 0 && acc[i] > 0.5) { chosen = i; break }
        }
        if (chosen < 0) {
            for (i in order) {
                if (nowPred[i] != 0) { chosen = i; break }
            }
        }
        if (chosen < 0) return base.copy(wait = true, grade = "WAIT", logic = "-", logicInfo = "No logic fits recent candles", reasons = "No clear setup")

        val dir = if (nowPred[chosen] > 0) Direction.CALL else Direction.PUT

        // অন্য ভালো লজিকগুলো একমত না দ্বিমত
        var support = 0.0
        for (i in order.take(4)) {
            if (i != chosen && nowPred[i] != 0 && acc[i] > 0.5) {
                support += (acc[i] - 0.5) * (if (nowPred[i] == nowPred[chosen]) 1.0 else -1.0)
            }
        }
        var conf = 50.0 + 70.0 * (acc[chosen] - 0.5)
        conf += (support * 20.0).coerceIn(-6.0, 4.0)
        conf += if (base.direction == dir) 3.0 else -3.0
        val atr = max(c.takeLast(min(14, n)).map { it.high - it.low }.average(), 1.0)
        val lm = liveDelta / atr
        val liveSign = if (lm > 0.35) 1 else if (lm < -0.35) -1 else 0
        if (liveSign != 0) conf += if (liveSign == nowPred[chosen]) 3.0 else -3.0
        val confInt = conf.coerceIn(50.0, 82.0).toInt()
        val grade = when {
            confInt >= 66 -> "STRONG"
            confInt >= 58 -> "MEDIUM"
            else -> "WEAK"
        }

        val st = strats[chosen]
        val backup = order.firstOrNull { it != chosen && acc[it] > 0.5 && nowPred[it] != 0 }
        val info = "Logic: ${st.name} ${hits[chosen]}/${cnt[chosen]} (${(acc[chosen] * 100).toInt()}%)" +
                (if (backup != null) " • Backup: ${strats[backup].name} ${hits[backup]}/${cnt[backup]}" else "") +
                " • Market: " + (if (er > 0.40) "Trending" else if (er < 0.25) "Ranging" else "Mixed")

        // শেষ ৬ ক্যান্ডেল কোন কারণে আপ/ডাউন হয়েছিল
        val parts = ArrayList<String>()
        for (j in (n - 6) until n) {
            val o = outcome[j]
            if (o == 0) { parts.add("•"); continue }
            var tag = "?"
            for (si in order) {
                if (hitAt[si][j] == 1) { tag = strats[si].abbr; break }
            }
            parts.add((if (o > 0) "↑" else "↓") + tag)
        }
        val explain = "Last candles: " + parts.joinToString(" ")

        val why = if (base.direction == dir) base.reasons else "Indicators lean ${base.direction.name}"
        // ---- বাছাই: সব শর্ত মিললে তবেই সিগন্যাল, নইলে WAIT ----
        var agree = 0
        var disagree = 0
        for (i in order.take(5)) {
            if (i != chosen && nowPred[i] != 0 && acc[i] > 0.5) {
                if (nowPred[i] == nowPred[chosen]) agree++ else disagree++
            }
        }
        val fails = ArrayList<String>()
        if (cnt[chosen] < 6) fails.add("Few setups (${cnt[chosen]}/6)")
        if (acc[chosen] < minAcc) fails.add("Backtest ${(acc[chosen] * 100).toInt()}% < ${(minAcc * 100).toInt()}%")
        if (base.direction != dir) fails.add("Indicators disagree")
        if (base.grade == "WEAK") fails.add("Indicators weak")
        if (agree < 1) fails.add("No 2nd logic agrees")
        if (disagree > 0) fails.add("Another logic disagrees")

        // ---- লেভেল: কতবার ছুঁয়েছে গুনে শক্ত সাপোর্ট/রেজিস্ট্যান্স, আর গ্রিডের রাউন্ড লেভেল ----
        val lv = Levels.build(c, atr, roundLevels)
        val lastP = c.last().close
        val strongUp = lv.filter { it.p > lastP && it.touches >= 2 }.minByOrNull { it.p }
        val strongDn = lv.filter { it.p < lastP && it.touches >= 2 }.maxByOrNull { it.p }
        if (dir == Direction.CALL && strongUp != null && strongUp.p - lastP < 0.5 * atr) {
            fails.add("Strong resistance just above (x${strongUp.touches})")
        }
        if (dir == Direction.PUT && strongDn != null && lastP - strongDn.p < 0.5 * atr) {
            fails.add("Strong support just below (x${strongDn.touches})")
        }
        // বড় ক্যান্ডেলের পর পিছু নেওয়া ঝুঁকির (আগের ক্যান্ডেল ২x ATR এর বেশি হলে)
        val lastRange = c.last().high - c.last().low
        if (lastRange > atr * 1.8) fails.add("Oversized last candle")
        var adj = 0
        if (dir == Direction.CALL && strongDn != null && lastP - strongDn.p < 0.6 * atr) adj += 2
        if (dir == Direction.PUT && strongUp != null && strongUp.p - lastP < 0.6 * atr) adj += 2
        val conf2 = (confInt + adj).coerceIn(50, 82)
        val grade2 = when {
            conf2 >= 66 -> "STRONG"
            conf2 >= 58 -> "MEDIUM"
            else -> "WEAK"
        }
        val shown = ArrayList<LevelInfo>()
        if (strongUp != null) shown.add(LevelInfo(strongUp.p, "R", strongUp.touches))
        if (strongDn != null) shown.add(LevelInfo(strongDn.p, "S", strongDn.touches))
        for (rv in lv.filter { it.round }.sortedBy { abs(it.p - lastP) }.take(2)) {
            if (shown.none { abs(it.p - rv.p) < 0.2 * atr }) shown.add(LevelInfo(rv.p, "RN", rv.touches))
        }

        val bt = "${hits[chosen]}/${cnt[chosen]} (${(acc[chosen] * 100).toInt()}%)"
        if (fails.isNotEmpty()) {
            return AiSignal(dir, conf2, "WAIT", fails.joinToString(" • "), n, base.score, st.name, info, explain, true, bt, shown)
        }
        return AiSignal(dir, conf2, grade2, why, n, base.score, st.name, info, explain, false, bt, shown)
    }
}

/* =============================================================================
 *  VIEWS  (AI লোগো বাটন + স্ক্যান লাইন)
 * ========================================================================== */

/** হীরার লোগো: কালো গোল-চৌকো ব্যাজ, সবুজ নিয়ন বর্ডার, হীরার মাঝখানে "S" */
class AiLogoView(ctx: Context) : View(ctx) {
    var status = "WAITING"
        set(value) { field = value; invalidate() }
    var statusColor = Color.parseColor("#00E676")
        set(value) { field = value; invalidate() }
    /** স্ক্যানের সময় true: লোগোতে সবুজ/লাল রঙ থাকে না, যেন ক্যান্ডেলের সাথে না মেশে */
    var neutral = false
        set(value) { field = value; invalidate() }

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F20B1A14") }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dp(4).toFloat()
    }
    private val outer = Paint(Paint.ANTI_ALIAS_FLAG)
    private val inner = Paint(Paint.ANTI_ALIAS_FLAG)
    private val letter = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = ctx.dp(27).toFloat(); typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val pillBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2050E14") }
    private val pillStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dp(2).toFloat()
    }
    private val pillText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = ctx.dp(11).toFloat(); typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val dia = Path()

    private fun diamond(cx: Float, cy: Float, r: Float) {
        dia.reset()
        dia.moveTo(cx, cy - r)
        dia.lineTo(cx + r, cy)
        dia.lineTo(cx, cy + r)
        dia.lineTo(cx - r, cy)
        dia.close()
    }

    override fun onDraw(c: Canvas) {
        val d = context.dp(1).toFloat()
        val side = width - 12f
        val box = RectF(6f, 6f, 6f + side, 6f + side)
        c.drawRoundRect(box, 20 * d, 20 * d, bg)
        border.color = if (neutral) 0xFF00E5FF.toInt() else 0xFF00C853.toInt()
        c.drawRoundRect(box, 20 * d, 20 * d, border)

        val cx = box.centerX()
        val cy = box.centerY()
        outer.color = if (neutral) 0xFF00E5FF.toInt() else 0xFF1FE57A.toInt()
        diamond(cx, cy, side * 0.42f)
        c.drawPath(dia, outer)
        inner.color = if (neutral) 0xFF2979FF.toInt() else 0xFF0B9A52.toInt()
        diamond(cx, cy, side * 0.27f)
        c.drawPath(dia, inner)
        c.drawText("S", cx, cy + 9 * d, letter)

        val pill = RectF(side * 0.04f + 6f, 6f + side + 6 * d, side * 0.96f + 6f, 6f + side + 28 * d)
        c.drawRoundRect(pill, 12 * d, 12 * d, pillBg)
        pillStroke.color = if (neutral) 0xFF00E5FF.toInt() else statusColor
        c.drawRoundRect(pill, 12 * d, 12 * d, pillStroke)
        pillText.color = statusColor
        c.drawText(status, cx, pill.centerY() + 4 * d, pillText)
    }
}

/** স্ক্যানের পর চার্টে সাপোর্ট/রেজিস্ট্যান্স ও রাউন্ড লেভেল নীল দাগে দেখায় */
class LevelView(ctx: Context) : View(ctx) {
    class Row(val y: Float, val label: String, val round: Boolean)

    private var rows: List<Row> = emptyList()
    private var left = 0f
    private var right = 0f
    private val solid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2979FF"); strokeWidth = ctx.dp(2).toFloat()
    }
    private val dashed = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#64B5F6"); strokeWidth = ctx.dp(1).toFloat()
        pathEffect = DashPathEffect(floatArrayOf(18f, 12f), 0f)
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#82B1FF"); textSize = ctx.dp(11).toFloat(); typeface = Typeface.DEFAULT_BOLD
    }

    fun show(r: List<Row>, l: Float, rr: Float) {
        rows = r; left = l; right = rr
        visibility = VISIBLE
        invalidate()
    }

    fun clear() {
        rows = emptyList()
        visibility = GONE
    }

    override fun onDraw(c: Canvas) {
        for (r in rows) {
            c.drawLine(left, r.y, right, r.y, if (r.round) dashed else solid)
            c.drawText(r.label, left + 8f, r.y - 6f, text)
        }
    }
}

/** বিশ্লেষণের সময় স্ক্রিন একটু অন্ধকার + চার্টের উপর দিয়ে ওঠানামা করা নীল স্ক্যান লাইন */
class ScanView(ctx: Context) : View(ctx) {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2979FF"); strokeWidth = ctx.dp(3).toFloat()
    }
    private val glow = Paint()
    private val dim = Paint().apply { color = 0x33000000 }
    private var top = 0
    private var bottom = 0
    private var pos = 0f
    private var anim: ValueAnimator? = null

    fun begin(t: Int, b: Int) {
        top = t; bottom = b
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener { pos = it.animatedValue as Float; invalidate() }
            start()
        }
        visibility = VISIBLE
    }

    fun end() {
        anim?.cancel(); anim = null
        visibility = GONE
    }

    override fun onDraw(c: Canvas) {
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        val y = top + (bottom - top) * pos
        val h = context.dp(46).toFloat()
        glow.shader = LinearGradient(
            0f, y - h, 0f, y + h,
            intArrayOf(0x002979FF, 0x662979FF, 0x002979FF),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, y - h, width.toFloat(), y + h, glow)
        c.drawLine(0f, y, width.toFloat(), y, line)
    }
}

/* =============================================================================
 *  TAP SERVICE  (Accessibility - অটো এন্ট্রির জন্য BUY/SELL বাটনে ট্যাপ)
 * ========================================================================== */

class TapService : AccessibilityService() {
    companion object {
        @Volatile var instance: TapService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesture, null, null)
    }
}

/* =============================================================================
 *  FRAME RECORDER  (একই ক্যাপচার ফ্রেম থেকে MP4 বানায়; দ্বিতীয় VirtualDisplay লাগে না,
 *  তাই রেকর্ড চালু থাকলেও মার্কেট স্ক্যান বন্ধ হয় না)
 * ========================================================================== */

class FrameRecorder(private val w: Int, private val h: Int) {
    private var codec: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var surface: Surface? = null
    private var thread: Thread? = null
    @Volatile private var started = false
    @Volatile private var stopAt = 0L
    @Volatile var active = false

    fun start(fd: FileDescriptor?, path: String?) {
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, 4_000_000)
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, 15)
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        val cd = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        cd.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        surface = cd.createInputSurface()
        cd.start()
        codec = cd
        muxer = if (fd != null) MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        else MediaMuxer(path!!, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        active = true
        thread = Thread { drain() }.also { it.start() }
    }

    private fun drain() {
        val cd = codec ?: return
        val mx = muxer ?: return
        val info = MediaCodec.BufferInfo()
        var track = -1
        try {
            while (true) {
                val idx = cd.dequeueOutputBuffer(info, 10_000)
                if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = mx.addTrack(cd.outputFormat)
                    mx.start()
                    started = true
                } else if (idx >= 0) {
                    val buf = cd.getOutputBuffer(idx)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && started && buf != null) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        mx.writeSampleData(track, buf, info)
                    }
                    cd.releaseOutputBuffer(idx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                }
                if (stopAt > 0 && SystemClock.uptimeMillis() - stopAt > 3000) break
            }
        } catch (_: Exception) {
        }
    }

    fun push(bmp: Bitmap) {
        if (!active) return
        try {
            val s = surface ?: return
            val cv = s.lockCanvas(null)
            cv.drawBitmap(bmp, null, Rect(0, 0, w, h), null)
            s.unlockCanvasAndPost(cv)
        } catch (_: Exception) {
        }
    }

    fun stop() {
        if (!active) return
        active = false
        stopAt = SystemClock.uptimeMillis()
        try { codec?.signalEndOfInputStream() } catch (_: Exception) {}
        try { thread?.join(3500) } catch (_: Exception) {}
        try { codec?.stop() } catch (_: Exception) {}
        try { codec?.release() } catch (_: Exception) {}
        try { if (started) muxer?.stop() } catch (_: Exception) {}
        try { muxer?.release() } catch (_: Exception) {}
        try { surface?.release() } catch (_: Exception) {}
        codec = null; muxer = null; surface = null; started = false
    }
}

/* =============================================================================
 *  OVERLAY SERVICE
 * ========================================================================== */

class OverlayService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "sahan_ai_channel"
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private val prefs by lazy { getSharedPreferences("sahan_ai", Context.MODE_PRIVATE) }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var captureDisplay: VirtualDisplay? = null
    private var frameRec: FrameRecorder? = null
    private var capThread: HandlerThread? = null
    private var lastRecAt = 0L
    private var recording = false
    private var recPfd: ParcelFileDescriptor? = null

    private var sw = 0
    private var sh = 0
    private var dpi = 0

    private lateinit var root: LinearLayout
    private lateinit var rootLp: WindowManager.LayoutParams
    private lateinit var logo: AiLogoView
    private lateinit var closeBtn: TextView
    private lateinit var popupBox: LinearLayout
    private lateinit var scanView: ScanView
    private lateinit var levelView: LevelView
    private val levelClear = Runnable { if (::levelView.isInitialized) levelView.clear() }
    private var lastEntryAt = 0L
    private val recentWait = ArrayList<Boolean>()      // শেষ বিশ্লেষণগুলোতে WAIT এসেছিল কিনা

    private var busy = false
    private var lastTfSec = 60
    private var analyzingPill: View? = null

    @Volatile private var lastBmp: Bitmap? = null
    @Volatile private var lastBmpAt = 0L
    private var lastConvertAt = 0L
    @Volatile private var imgCount = 0
    @Volatile private var okCount = 0
    @Volatile private var lastErr = ""
    @Volatile private var tickerTotal = 0L
    private var tickerStart = 0L

    // অটো সিগন্যাল সিঙ্ক
    private var armed = true
    private var lastRem = -1
    private var lastFallback = 0L
    private var syncBusy = false

    private fun tfMode() = prefs.getInt("tf", 0).coerceIn(0, 3)          // 0=AUTO, 1=5s, 2=10s, 3=1m
    private fun fixedTf(): Int? = when (tfMode()) { 1 -> 5; 2 -> 10; 3 -> 60; else -> null }
    private fun analysisSec(tf: Int) = if (tf <= 5) 2 else if (tf <= 10) 3 else 4
    private fun tfLabel(tf: Int) = if (tf >= 60) "${tf / 60}m" else "${tf}s"
    private fun bucketTf(expiry: Int) = if (expiry <= 7) 5 else if (expiry <= 20) 10 else 60

    private val syncLoop = object : Runnable {
        override fun run() {
            if (!prefs.getBoolean("auto_signal", false)) return
            if (!busy && !syncBusy) {
                syncBusy = true
                Thread {
                    var rem: Int? = null
                    val b = lastBmp
                    if (b != null) {
                        val lines = Ocr.read(b, Geo.priceCrop(b))
                        rem = Ocr.parseCountdownNear(lines, Ocr.findPriceRect(b, lines)?.second)
                    }
                    ui.post { syncBusy = false; onCountdown(rem) }
                }.start()
            }
            ui.postDelayed(this, 900)
        }
    }

    /** ক্যান্ডেল শেষ হওয়ার ঠিক আগে নিজে বিশ্লেষণ শুরু করে, যেন সিগন্যাল পরের ক্যান্ডেলের শুরুতে আসে */
    private fun onCountdown(rem: Int?) {
        if (busy || !prefs.getBoolean("auto_signal", false)) return
        val tf = fixedTf() ?: lastTfSec
        val lead = analysisSec(tf) + 2 + 1          // স্ক্যান + ফ্রেম অপেক্ষা + একটু মার্জিন
        if (rem != null) {
            if (lastRem in 0 until rem) armed = true     // কাউন্টডাউন বেড়েছে = নতুন ক্যান্ডেল
            lastRem = rem
            if (armed && rem <= lead && rem >= 1) {
                armed = false
                analyzeNow()
            }
        } else {
            val now = SystemClock.uptimeMillis()
            if (now - lastFallback >= max(tf, analysisSec(tf) + 3) * 1000L) {
                lastFallback = now
                analyzeNow()
            }
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            "auto_signal" -> {
                ui.removeCallbacks(syncLoop)
                if (prefs.getBoolean("auto_signal", false)) {
                    armed = true; lastRem = -1; lastFallback = 0L
                    ui.post(syncLoop)
                }
            }
            "record" -> if (prefs.getBoolean("record", false)) startRecord() else stopRecord()
            else -> {}
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!busy) return
            val left = max(0L, tickerTotal - (SystemClock.uptimeMillis() - tickerStart))
            logo.status = String.format(Locale.US, "%.1fs", left / 1000.0)
            ui.postDelayed(this, 100)
        }
    }

    private val logoReset = Runnable {
        if (!busy) {
            logo.status = "WAITING"; logo.statusColor = Color.parseColor("#00E676")
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        if (projection == null) {
            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            setupScreenMetrics()
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mpm.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { ui.post { stopSelf() } }
            }, ui)
            // নিরাপত্তা: সার্ভিস চালুর সময় অটো ফিচার বন্ধ থেকে শুরু হয়
            prefs.edit().putBoolean("auto_signal", false).putBoolean("auto_entry", false)
                .putBoolean("record", false).apply()
            prefs.registerOnSharedPreferenceChangeListener(prefListener)
            setupCapture()
            buildOverlay()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Sahan Ai Elite", NotificationManager.IMPORTANCE_LOW))
        }
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this))
            .setContentTitle("Sahan Ai Elite চলছে")
            .setContentText("AI বাটনে ট্যাপ করলে মার্কেট স্ক্যান হবে")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun setupScreenMetrics() {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        sw = m.widthPixels; sh = m.heightPixels; dpi = m.densityDpi
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    /* ---------------- স্ক্রিন ক্যাপচার ---------------- */

    private fun makeReader(): ImageReader {
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        reader = r
        val ht = HandlerThread("ai_capture")
        ht.start()
        capThread = ht
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { lastErr = "acquire: ${e.message}"; null }
            if (img != null) {
                imgCount++
                try {
                    val now = SystemClock.uptimeMillis()
                    val fr = frameRec
                    val needA = now - lastConvertAt >= 300
                    val needR = fr != null && now - lastRecAt >= 80
                    if (needA || needR) {
                        val plane = img.planes[0]
                        val rowStride = plane.rowStride
                        val bw = rowStride / plane.pixelStride
                        // বাফারের শেষ সারিতে প্যাডিং না থাকলে সরাসরি কপি করলে এরর হয়, তাই আগে পূর্ণ আকারের অ্যারেতে নিই
                        val bytes = ByteArray(rowStride * sh)
                        val buf = plane.buffer
                        buf.rewind()
                        buf.get(bytes, 0, min(buf.remaining(), bytes.size))
                        val full = Bitmap.createBitmap(bw, sh, Bitmap.Config.ARGB_8888)
                        full.copyPixelsFromBuffer(ByteBuffer.wrap(bytes))
                        val bmp = if (bw == sw) full else Bitmap.createBitmap(full, 0, 0, sw, sh)
                        if (needA) {
                            lastConvertAt = now
                            lastBmp = bmp
                            lastBmpAt = SystemClock.uptimeMillis()
                            okCount++
                        }
                        if (needR && fr != null) {
                            lastRecAt = now
                            fr.push(bmp)
                        }
                    }
                } catch (e: Throwable) {
                    lastErr = e.javaClass.simpleName + ": " + (e.message ?: "")
                } finally {
                    img.close()
                }
            }
        }, Handler(ht.looper))
        return r
    }

    private fun setupCapture() {
        val r = makeReader()
        captureDisplay = projection?.createVirtualDisplay(
            "AI_capture", sw, sh, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    /** কমপক্ষে ০.৩৫ সেকেন্ড পরের একটি নতুন ফ্রেম */
    private fun waitFreshFrame(): Bitmap? {
        val t0 = SystemClock.uptimeMillis()
        while (SystemClock.uptimeMillis() - t0 < 2500) {
            val b = lastBmp
            if (b != null && lastBmpAt >= t0 + 350) return b
            Thread.sleep(40)
        }
        if (lastBmp == null && imgCount == 0) ui.post { recreateCapture() }
        return lastBmp
    }

    /** নতুন মাপের ImageReader বানিয়ে আগের VirtualDisplay-তে বসায় (নতুন VirtualDisplay লাগে না, তাই সব Android এ চলে) */
    private fun recreateCapture() {
        try {
            val oldReader = reader
            val oldThread = capThread
            val r = makeReader()
            val vd = captureDisplay
            if (vd != null) {
                vd.resize(sw, sh, dpi)
                vd.setSurface(r.surface)
            } else {
                captureDisplay = projection?.createVirtualDisplay(
                    "AI_capture", sw, sh, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
                )
            }
            try { oldReader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
            try { oldReader?.close() } catch (_: Exception) {}
            try { oldThread?.quitSafely() } catch (_: Exception) {}
        } catch (e: Exception) {
            lastErr = "recreate: ${e.message}"
        }
    }

    /** ফোন ঘোরালে (সোজা ↔ আড়াআড়ি) স্ক্রিনের মাপ নতুন করে নিয়ে ক্যাপচার ঠিক করে */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        ui.postDelayed({ handleRotation() }, 700)
    }

    private fun handleRotation() {
        if (projection == null || !::wm.isInitialized) return
        val ow = sw
        val oh = sh
        setupScreenMetrics()
        if (sw == ow && sh == oh) return
        lastBmp = null
        lastBmpAt = 0L
        recreateCapture()
        if (::rootLp.isInitialized && ::root.isInitialized) {
            rootLp.x = min(rootLp.x, max(0, sw - dp(300)))
            rootLp.y = min(rootLp.y, max(0, sh - dp(140)))
            try { wm.updateViewLayout(root, rootLp) } catch (_: Exception) {}
        }
    }

    /* ---------------- ওভারলে UI ---------------- */

    private fun overlayParams(w: Int, h: Int, flags: Int, gravity: Int, x: Int = 0, y: Int = 0) =
        WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).also { it.gravity = gravity; it.x = x; it.y = y }

    private fun buildOverlay() {
        scanView = ScanView(this)
        scanView.visibility = View.GONE
        wm.addView(
            scanView,
            overlayParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                Gravity.TOP or Gravity.START
            )
        )

        levelView = LevelView(this)
        levelView.visibility = View.GONE
        wm.addView(
            levelView,
            overlayParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                Gravity.TOP or Gravity.START
            )
        )

        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val topRow = FrameLayout(this)
        logo = AiLogoView(this)
        topRow.addView(logo, FrameLayout.LayoutParams(dp(84), dp(114), Gravity.CENTER_HORIZONTAL))
        closeBtn = TextView(this).apply {
            text = "✕"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#B3424A55")) }
            visibility = View.GONE
            setOnClickListener { removeLastPopup() }
        }
        topRow.addView(closeBtn, FrameLayout.LayoutParams(dp(38), dp(38), Gravity.END or Gravity.TOP).apply {
            topMargin = dp(22); rightMargin = dp(16)
        })
        root.addView(topRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        popupBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(popupBox, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        rootLp = overlayParams(
            dp(300), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            Gravity.TOP or Gravity.START, max(0, (sw - dp(300)) / 2), dp(330)
        )

        // AI বাটন: ট্যাপ = স্ক্যান, টেনে সরানো, ধরে রাখলে স্ক্রিন রেকর্ড
        logo.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false; var longFired = false
            val longPress = Runnable {
                longFired = true
                prefs.edit().putBoolean("record", !recording).apply()
            }
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = rootLp.x; sy = rootLp.y; tx = e.rawX; ty = e.rawY; moved = false; longFired = false
                        ui.postDelayed(longPress, 900)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) { moved = true; ui.removeCallbacks(longPress) }
                        if (moved) {
                            rootLp.x = sx + dx; rootLp.y = sy + dy
                            wm.updateViewLayout(root, rootLp)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        ui.removeCallbacks(longPress)
                        if (!moved && !longFired) analyzeNow()
                    }
                    MotionEvent.ACTION_CANCEL -> ui.removeCallbacks(longPress)
                }
                return true
            }
        })
        wm.addView(root, rootLp)
    }

    /* ---------------- পপআপ ---------------- */

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun pill(t: String, color: Int) = TextView(this).apply {
        text = t; textSize = 14f; setTextColor(color); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#F2101820")); cornerRadius = dp(22).toFloat(); setStroke(dp(2), color)
        }
    }

    private fun resultCard(r: AiSignal, tf: Int): View {
        val up = r.direction == Direction.CALL
        val color = if (up) Color.parseColor("#00E676") else Color.parseColor("#FF5252")
        val gradeColor = when (r.grade) {
            "STRONG" -> Color.parseColor("#00E676")
            "MEDIUM" -> Color.parseColor("#FFD54F")
            else -> Color.parseColor("#FF9800")
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2101820")); cornerRadius = dp(18).toFloat(); setStroke(dp(2), color)
            }
        }
        card.addView(tv(if (up) "CALL ▲" else "PUT ▼", 22f, color, true))
        card.addView(tv("Backtest ${r.backtest}", 17f, color, true))
        card.addView(tv("Past-candle score — not a win chance", 10.5f, gradeColor, true))
        if (r.forced) card.addView(tv("⚠ WAIT সীমার কারণে দেওয়া দুর্বল সিগন্যাল", 10.5f, Color.parseColor("#FF9800"), true))
        card.addView(tv("Next ${tfLabel(tf)} candle", 11f, Color.parseColor("#B0BEC5")))
        if (r.logicInfo.isNotEmpty()) card.addView(tv(r.logicInfo, 11f, Color.parseColor("#80DEEA"), true))
        card.addView(tv(r.reasons, 10.5f, Color.parseColor("#90A4AE")))
        if (r.explain.isNotEmpty()) card.addView(tv(r.explain, 10f, Color.parseColor("#78909C")))
        card.addView(tv("Estimate only — not guaranteed", 10f, Color.parseColor("#78909C")))
        return card
    }

    private fun addPopup(v: View, autoRemoveMs: Long = 0L) {
        val lp = LinearLayout.LayoutParams(dp(280), LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) }
        popupBox.addView(v, lp)
        closeBtn.visibility = View.VISIBLE
        if (autoRemoveMs > 0) ui.postDelayed({ removePopup(v) }, autoRemoveMs)
    }

    private fun removePopup(v: View) {
        popupBox.removeView(v)
        if (v === analyzingPill) analyzingPill = null
        if (popupBox.childCount == 0) closeBtn.visibility = View.GONE
    }

    /** X চাপলে সবচেয়ে নতুন পপআপ সরে যায়; এভাবে এক এক করে সব সরানো যায় */
    private fun removeLastPopup() {
        val n = popupBox.childCount
        if (n > 0) removePopup(popupBox.getChildAt(n - 1))
    }

    private fun clearPopups() {
        popupBox.removeAllViews()
        analyzingPill = null
        closeBtn.visibility = View.GONE
    }

    /* ---------------- স্ক্যান ও সিগন্যাল ---------------- */

    private fun analyzeNow() {
        if (busy) return
        busy = true
        ui.removeCallbacks(logoReset)
        ui.removeCallbacks(levelClear)
        levelView.clear()
        val withEntry = prefs.getBoolean("auto_entry", false)
        val track = prefs.getBoolean("track", true)

        clearPopups()
        if (!withEntry) {                      // অটো এন্ট্রি চালু থাকলে কোনো পপআপ নয়
            val pillView = pill("● ANALYZING MARKET", Color.parseColor("#2979FF"))
            analyzingPill = pillView
            addPopup(pillView)
        }
        logo.neutral = true
        logo.statusColor = Color.parseColor("#FFD54F")
        tickerStart = SystemClock.uptimeMillis()
        tickerTotal = 5500L
        ui.post(ticker)

        Thread {
            try {
            ui.post { scanView.visibility = View.GONE }
            val b1 = waitFreshFrame()
            if (b1 == null) { ui.post { marketNotVisible(withEntry, "no frame img=$imgCount ok=$okCount ${lastErr.take(60)}") }; return@Thread }

            // ট্রেড টাইম: Quotex এর Timer পড়া (AUTO হলে), না পারলে আগেরটা
            var tf = fixedTf() ?: lastTfSec
            if (fixedTf() == null) {
                val ex = Ocr.parseExpirySeconds(Ocr.read(b1, Geo.expiryCrop(b1)))
                if (ex != null) tf = bucketTf(ex)
            }
            lastTfSec = tf
            val secs = analysisSec(tf)
            tickerTotal = secs * 1000L + 1200L
            tickerStart = SystemClock.uptimeMillis()

            // চার্ট এলাকা নিজে খোঁজা; কম ক্যান্ডেল পেলে আরও দু'ভাবে চেষ্টা
            val cr = Geo.chart(b1)
            val left = cr[0]
            val right = cr[2]
            var top = cr[1]
            var bottom = cr[3]
            var c1 = ChartReader.detect(b1, top, bottom, left, right)
            if (c1.size < 10 && !Geo.land(b1)) {
                for (alt in listOf(0.12f to 0.70f, 0.10f to 0.78f)) {
                    val t = (b1.height * alt.first).toInt()
                    val bt = (b1.height * alt.second).toInt()
                    val c = ChartReader.detect(b1, t, bt)
                    if (c.size > c1.size) { c1 = c; top = t; bottom = bt }
                }
            }
            if (c1.size < 10) {
                val n = c1.size
                ui.post { marketNotVisible(withEntry, "candles: $n") }
                return@Thread
            }
            val chartTop = top
            val chartBottom = bottom

            // স্ক্রিন একটু অন্ধকার + নীল স্ক্যান লাইন
            val sw2 = Geo.sweep(b1, chartBottom)
            ui.post { scanView.begin(sw2.first, sw2.second) }
            Thread.sleep(secs * 1000L)

            // শেষ পরিষ্কার ফ্রেম
            ui.post { scanView.end() }
            val b2raw = waitFreshFrame() ?: b1
            val b2 = if (b2raw.width == b1.width && b2raw.height == b1.height) b2raw else b1   // মাঝখানে ফোন ঘুরে গেলে আগের ছবিই ব্যবহার
            val c2 = ChartReader.detect(b2, chartTop, chartBottom, left, right)
            val finalCandles = if (c2.size >= 10) c2 else c1
            val delta = if (c2.size >= 10) c2.last().close - c1.last().close else 0.0
            // নিজের আগের ট্রেডের ফল থেকে প্রতিটা লজিকের জয়-হার
            val liveStats = HashMap<String, Pair<Int, Int>>()
            for (e in HistoryStore.load(this).takeLast(40)) {
                if (e.logic.isEmpty()) continue
                val cur = liveStats[e.logic] ?: (0 to 0)
                if (e.result == "WIN") liveStats[e.logic] = (cur.first + 1) to cur.second
                else if (e.result == "LOSS") liveStats[e.logic] = cur.first to (cur.second + 1)
            }
            // চার্টের ডানের দামের লেবেল (রাউন্ড লেভেল) ও বর্তমান প্রাইস একবারেই পড়া
            val lines2 = Ocr.read(b2, Geo.priceCrop(b2))
            val priceHit = Ocr.findPriceRect(b2, lines2)
            val axis = Ocr.axisLabels(b2, lines2, priceHit?.second)
            val regionH = (chartBottom - chartTop).toDouble()
            val roundLevels = axis.filter { it.first in chartTop..chartBottom }.map { regionH - (it.first - chartTop) }

            val res = LogicEngine.analyze(finalCandles, delta, tf, liveStats, prefs.getInt("min_acc", 80) / 100.0, roundLevels)

            // এন্ট্রি প্রাইস ও BUY/SELL বাটনের জায়গা
            val entryPrice = if (track) (priceHit?.first ?: 0.0) else 0.0
            val btn = if (withEntry) Geo.buttons(b2) else null

            ui.post {
                busy = false
                logo.neutral = false

                // WAIT সীমা: শেষ ১০টার মধ্যে সর্বোচ্চ N টা WAIT; সীমা পেরোলে দুর্বল সিগন্যাল জোর করে দেওয়া হয়
                var res2 = res
                if (res.wait) {
                    val maxW = prefs.getInt("max_wait", 3)
                    val prevWaits = recentWait.takeLast(9).count { it }
                    if (maxW < 10 && prevWaits >= maxW) {
                        res2 = res.copy(wait = false, grade = "WEAK", forced = true, reasons = "Forced: " + res.reasons)
                    }
                }
                recentWait.add(res2.wait)
                if (recentWait.size > 30) recentWait.removeAt(0)

                showResult(res2, tf, withEntry)
                if (!withEntry && prefs.getBoolean("levels", true)) showLevels(res2, chartTop, chartBottom, left, right, axis)
                if (!res2.wait) {
                    var entered = false
                    if (withEntry) entered = performAutoEntry(res2, btn)
                    if (track) {
                        val id = System.currentTimeMillis()
                        val tag = res2.logic + (if (res2.forced) " (forced)" else "")
                        HistoryStore.add(this, HistoryEntry(id, res2.direction.name, res2.confidence, tf, entryPrice, 0.0, "PENDING", entered, false, tag))
                        scheduleExit(id, tf, 0)
                    }
                }
            }
            } catch (e: Throwable) {
                val msg = e.javaClass.simpleName + ": " + (e.message ?: "")
                ui.post { marketNotVisible(withEntry, "error " + msg.take(50)) }
            }
        }.start()
    }

    private fun marketNotVisible(withEntry: Boolean, info: String) {
        busy = false
        scanView.end()
        logo.neutral = false
        analyzingPill?.let { removePopup(it) }
        logo.status = "WAITING"; logo.statusColor = Color.parseColor("#00E676")
        if (!withEntry) addPopup(pill("✖ CAN'T SEE MARKET\nOpen the candle chart\n($info)", Color.parseColor("#FF5252")), 8000)
    }

    @Suppress("DEPRECATION")
    private fun alertUser() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(350, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    private fun showLevels(res: AiSignal, top: Int, bottom: Int, l: Int, r: Int, axis: List<Pair<Int, String>>) {
        val regionH = (bottom - top).toDouble()
        val rows = ArrayList<LevelView.Row>()
        for (lv in res.levels) {
            val y = top + (regionH - lv.p).toFloat()
            if (y < top || y > bottom) continue
            val label = when (lv.kind) {
                "R" -> "RESISTANCE x${lv.touches}"
                "S" -> "SUPPORT x${lv.touches}"
                else -> {
                    val near = axis.minByOrNull { abs(it.first - y) }
                    if (near != null && abs(near.first - y) < 10) "ROUND ${near.second}" else "ROUND"
                }
            }
            rows.add(LevelView.Row(y, label, lv.kind == "RN"))
        }
        if (rows.isEmpty()) return
        levelView.show(rows, l.toFloat(), r.toFloat())
        ui.removeCallbacks(levelClear)
        ui.postDelayed(levelClear, 12000)
    }

    private fun waitCard(r: AiSignal, tf: Int): View {
        val color = Color.parseColor("#B0BEC5")
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2101820")); cornerRadius = dp(18).toFloat(); setStroke(dp(2), color)
            }
        }
        card.addView(tv("WAIT", 24f, color, true))
        card.addView(tv("No safe setup for next ${tfLabel(tf)} candle", 11.5f, Color.parseColor("#CFD8DC")))
        card.addView(tv(r.reasons, 11f, Color.parseColor("#FFB74D"), true))
        if (r.logicInfo.isNotEmpty()) card.addView(tv(r.logicInfo, 10.5f, Color.parseColor("#80DEEA")))
        card.addView(tv("পরের ক্যান্ডেলে আবার চেষ্টা করো", 10f, Color.parseColor("#78909C")))
        return card
    }

    private fun showResult(r: AiSignal, tf: Int, withEntry: Boolean) {
        if (r.wait) {
            logo.status = "WAIT"; logo.statusColor = Color.parseColor("#B0BEC5")
            analyzingPill?.let { removePopup(it) }
            if (!withEntry) addPopup(waitCard(r, tf), 10000)
            ui.postDelayed(logoReset, 10000)
            return
        }
        alertUser()
        val up = r.direction == Direction.CALL
        logo.status = if (up) "CALL ▲" else "PUT ▼"
        logo.statusColor = if (up) Color.parseColor("#00E676") else Color.parseColor("#FF5252")
        analyzingPill?.let { removePopup(it) }
        if (!withEntry) addPopup(resultCard(r, tf), 12000)
        ui.postDelayed(logoReset, 12000)
    }

    /* ---------------- অটো এন্ট্রি (কোনো সীমা নেই) ---------------- */

    private fun performAutoEntry(r: AiSignal, btn: FloatArray?): Boolean {
        if (r.confidence < prefs.getInt("entry_min", 0)) return false
        if (r.forced && prefs.getBoolean("skip_forced", true)) return false     // দুর্বল (forced) সিগন্যালে অটো এন্ট্রি নয়
        if (btn == null) { toast("BUY/SELL বাটন খুঁজে পাওয়া যায়নি — ট্রেডিং স্ক্রিন খোলা রাখো"); return false }
        val svc = TapService.instance
        if (svc == null) { toast("ACCESSIBILITY চালু নেই"); return false }
        val x = if (r.direction == Direction.CALL) btn[0] else btn[2]
        val y = if (r.direction == Direction.CALL) btn[1] else btn[3]
        // একই ক্যান্ডেলে দ্বিতীয়বার এন্ট্রি আটকানো
        val now = SystemClock.uptimeMillis()
        if (now - lastEntryAt < max(lastTfSec * 800L, 4000L)) {
            toast("একই ক্যান্ডেলে দ্বিতীয় এন্ট্রি আটকানো হয়েছে")
            return false
        }
        val ok = svc.tap(x, y)
        if (ok) lastEntryAt = now
        return ok
    }

    /* ---------------- ফলাফল জমা (WIN / LOSS / DRAW) ---------------- */

    private fun scheduleExit(id: Long, tf: Int, tries: Int) {
        val delay = if (tries == 0) tf * 1000L + 2500L else 800L
        ui.postDelayed({
            if (busy && tries < 14) {
                scheduleExit(id, tf, tries + 1)
                return@postDelayed
            }
            Thread {
                ui.post { root.visibility = View.INVISIBLE }
                val b = waitFreshFrame()
                ui.post { root.visibility = View.VISIBLE }
                var price: Double? = null
                if (b != null) {
                    price = Ocr.findPrice(b, Ocr.read(b, Geo.priceCrop(b)))
                }
                val exitPrice = price
                HistoryStore.update(this, id) { x ->
                    if (!x.fixed) {
                        if (exitPrice == null || x.entry == 0.0) {
                            x.result = "UNKNOWN"
                            x.exit = exitPrice ?: 0.0
                        } else {
                            x.exit = exitPrice
                            x.result = when {
                                exitPrice == x.entry -> "DRAW"
                                (x.dir == "CALL") == (exitPrice > x.entry) -> "WIN"
                                else -> "LOSS"
                            }
                        }
                    }
                }
            }.start()
        }, delay)
    }

    /* ---------------- স্ক্রিন রেকর্ড (অ্যাপের সুইচ বা S বাটন ধরে রাখলে) ---------------- */

    private fun startRecord() {
        if (recording) return
        try {
            val name = "S_rec_${System.currentTimeMillis()}.mp4"
            val fr = FrameRecorder(sw, sh)
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SahanAiSmart")
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: throw IllegalStateException("সেভ করার জায়গা পাওয়া যায়নি")
                recPfd = contentResolver.openFileDescriptor(uri, "rw")
                fr.start(recPfd!!.fileDescriptor, null)
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
                fr.start(null, File(dir, name).absolutePath)
            }
            frameRec = fr
            recording = true
            toast("স্ক্রিন রেকর্ড শুরু হয়েছে")
        } catch (e: Exception) {
            toast("রেকর্ড শুরু করা যায়নি: ${e.message}")
            releaseRecorder()
            prefs.edit().putBoolean("record", false).apply()
        }
    }

    private fun stopRecord() {
        if (!recording) return
        releaseRecorder()
        toast("রেকর্ডিং সেভ হয়েছে — গ্যালারি → Movies/SahanAiSmart")
    }

    private fun releaseRecorder() {
        val fr = frameRec
        frameRec = null
        try { fr?.stop() } catch (_: Exception) {}
        try { recPfd?.close() } catch (_: Exception) {}
        recPfd = null; recording = false
    }

    /* ---------------- ক্লিনআপ ---------------- */

    override fun onDestroy() {
        busy = false
        ui.removeCallbacksAndMessages(null)
        try { prefs.unregisterOnSharedPreferenceChangeListener(prefListener) } catch (_: Exception) {}
        prefs.edit().putBoolean("auto_signal", false).putBoolean("auto_entry", false)
            .putBoolean("record", false).apply()
        releaseRecorder()
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        captureDisplay?.release()
        reader?.close()
        projection?.stop()
        try { capThread?.quitSafely() } catch (_: Exception) {}
        if (::wm.isInitialized) {
            if (::root.isInitialized) try { wm.removeView(root) } catch (_: Exception) {}
            if (::scanView.isInitialized) try { wm.removeView(scanView) } catch (_: Exception) {}
            if (::levelView.isInitialized) try { wm.removeView(levelView) } catch (_: Exception) {}
        }
        super.onDestroy()
    }
}

/* =============================================================================
 *  MAIN ACTIVITY  (সেটিংস + ফলাফল + START/STOP)
 * ========================================================================== */

class MainActivity : Activity() {

    private val REQ_OVERLAY = 101
    private val REQ_CAPTURE = 102
    private val prefs by lazy { getSharedPreferences("sahan_ai", Context.MODE_PRIVATE) }
    private val ui = Handler(Looper.getMainLooper())

    private val BG = Color.parseColor("#070D17")
    private val CARD = Color.parseColor("#0F1B2D")
    private val EDGE = Color.parseColor("#1D3453")
    private val ACCENT = Color.parseColor("#00E676")
    private val CYAN = Color.parseColor("#00E5FF")
    private val MUTED = Color.parseColor("#8DA2B8")

    private val tfLabels = listOf("AUTO", "5s", "10s", "1m")
    private val minLabels = listOf("ANY", "55%", "60%", "65%")
    private val minValues = listOf(0, 55, 60, 65)
    private val accLabels = listOf("70%", "75%", "80%", "85%")
    private val accValues = listOf(70, 75, 80, 85)
    private val accBtns = ArrayList<Button>()
    private val waitLabels = listOf("2", "3", "5", "∞")
    private val waitValues = listOf(2, 3, 5, 10)
    private val waitBtns = ArrayList<Button>()
    private lateinit var swSkip: Switch

    private val tfBtns = ArrayList<Button>()
    private val minBtns = ArrayList<Button>()
    private lateinit var swSignal: Switch
    private lateinit var swEntry: Switch
    private lateinit var swRecord: Switch
    private lateinit var swTrack: Switch
    private lateinit var swLevels: Switch
    private lateinit var settingsView: ScrollView
    private lateinit var resultsView: ScrollView
    private lateinit var resultsBox: LinearLayout
    private lateinit var statsText: TextView
    private lateinit var tabSettings: Button
    private lateinit var tabResults: Button
    private var resultsVisible = false

    private val refresher = object : Runnable {
        override fun run() {
            if (resultsVisible) {
                renderResults()
                ui.postDelayed(this, 2000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
        }

        // হেডার: লোগো + নাম
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(26), dp(18), dp(8))
        }
        val logo = AiLogoView(this).apply { status = "SAHAN AI" }
        header.addView(logo, LinearLayout.LayoutParams(dp(78), dp(106)))
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        titleBox.addView(TextView(this).apply {
            text = "Sahan Ai Elite"; textSize = 24f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
        })
        titleBox.addView(TextView(this).apply {
            text = "বাছাই করা সিগন্যাল • সুযোগ না থাকলে WAIT\n১১ লজিক • আগের ক্যান্ডেলে ব্যাকটেস্ট"
            textSize = 12f; setTextColor(CYAN)
        })
        header.addView(titleBox)
        page.addView(header)

        // ট্যাব
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(14), dp(4), dp(14), dp(8)) }
        tabSettings = Button(this).apply { text = "SETTINGS"; setOnClickListener { showTab(false) } }
        tabResults = Button(this).apply { text = "RESULTS"; setOnClickListener { showTab(true) } }
        tabs.addView(tabSettings, LinearLayout.LayoutParams(0, dp(44), 1f).apply { rightMargin = dp(6) })
        tabs.addView(tabResults, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(6) })
        page.addView(tabs)

        val content = FrameLayout(this)
        settingsView = buildSettings()
        resultsView = buildResults()
        content.addView(settingsView)
        content.addView(resultsView)
        page.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(page)
        showTab(false)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
        if (resultsVisible) { ui.removeCallbacks(refresher); ui.post(refresher) }
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(refresher)
    }

    /* ---------- সাজসজ্জার ছোট ফাংশন ---------- */

    private fun roundBg(color: Int, radius: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = roundBg(CARD, 18, EDGE)
    }

    private fun lpCard() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(10) }

    private fun heading(t: String) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(CYAN); typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(6))
    }

    private fun note(t: String) = TextView(this).apply {
        text = t; textSize = 11f; setTextColor(MUTED); setPadding(0, dp(6), 0, 0)
    }

    private fun styledButton(t: String, color: Int, textColor: Int = Color.WHITE) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(textColor); typeface = Typeface.DEFAULT_BOLD
        background = roundBg(color, 14)
    }

    private fun chipRow(labels: List<String>, store: MutableList<Button>, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        labels.forEachIndexed { i, t ->
            val b = Button(this).apply {
                text = t; textSize = 12f; isAllCaps = false; minWidth = 0; minimumWidth = 0
                setOnClickListener { onPick(i) }
            }
            store.add(b)
            row.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(3); rightMargin = dp(3) })
        }
        return row
    }

    private fun styleChips(btns: List<Button>, selected: Int) {
        btns.forEachIndexed { i, b ->
            val on = i == selected
            b.background = roundBg(if (on) ACCENT else Color.parseColor("#1A2A44"), 12)
            b.setTextColor(if (on) Color.parseColor("#04210F") else Color.parseColor("#B7C6D9"))
            b.typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }

    private fun switchRow(t: String, sub: String, onChange: (Boolean) -> Unit): Pair<LinearLayout, Switch> {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(4)) }
        val sw = Switch(this).apply {
            text = t; textSize = 15f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setOnCheckedChangeListener { _, on -> onChange(on) }
        }
        box.addView(sw)
        box.addView(note(sub))
        return box to sw
    }

    /* ---------- সেটিংস ---------- */

    private fun buildSettings(): ScrollView {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(14), dp(24)) }
        sv.addView(col)

        // START / STOP
        val c0 = card()
        val row0 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row0.addView(styledButton("START", ACCENT, Color.parseColor("#04210F")).apply { setOnClickListener { start() } },
            LinearLayout.LayoutParams(0, dp(52), 1f).apply { rightMargin = dp(6) })
        row0.addView(styledButton("STOP", Color.parseColor("#C62828")).apply {
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }, LinearLayout.LayoutParams(0, dp(52), 1f).apply { leftMargin = dp(6) })
        c0.addView(row0)
        c0.addView(note("START চেপে পারমিশন দাও, তারপর Quotex খুলে চার্টের উপর AI বাটনে ট্যাপ করো। বাটন ধরে রাখলে স্ক্রিন রেকর্ড শুরু/বন্ধ হবে।"))
        col.addView(c0, lpCard())

        // ক্যান্ডেল টাইম
        val c1 = card()
        c1.addView(heading("ক্যান্ডেল / ট্রেড টাইম"))
        c1.addView(chipRow(tfLabels, tfBtns) { i -> prefs.edit().putInt("tf", i).apply(); refresh() })
        c1.addView(note("AUTO: Quotex এর Timer (যেমন 00:01:00) ও ক্যান্ডেলের কাউন্টডাউন নিজে পড়ে। না পড়তে পারলে আগের টাইম ধরে। 5s / 10s / 1m বেছে নিলে ওই টাইমের পরের ক্যান্ডেলের সিগন্যাল দেবে।"))
        col.addView(c1, lpCard())

        // অটো ফিচার
        val c2 = card()
        c2.addView(heading("AUTO"))
        val s1 = switchRow("AUTO SIGNAL", "চালু থাকলে ক্যান্ডেল শেষ হওয়ার ঠিক আগে নিজে বিশ্লেষণ করে পরের ক্যান্ডেলের সিগন্যাল দেয়। বন্ধ থাকলে তুমি AI বাটনে চাপলে সিগন্যাল দেবে।") { on ->
            prefs.edit().putBoolean("auto_signal", on).apply()
        }
        swSignal = s1.second
        c2.addView(s1.first)
        val s2 = switchRow("AUTO ENTRY", "চালু থাকলে সিগন্যাল আসামাত্র BUY/SELL বাটনে নিজে ট্যাপ করে। কোনো সীমা নেই, যতক্ষণ চালু ততক্ষণ চলবে। বন্ধ থাকলে শুধু সিগন্যাল দেখাবে।") { on ->
            if (on && TapService.instance == null) {
                Toast.makeText(this, "আগে ACCESSIBILITY এ Sahan Ai Elite অন করো", Toast.LENGTH_LONG).show()
                swEntry.isChecked = false
            } else {
                prefs.edit().putBoolean("auto_entry", on).apply()
            }
        }
        swEntry = s2.second
        c2.addView(s2.first)
        c2.addView(note("AUTO SIGNAL ও AUTO ENTRY দুটো একসাথে চালু থাকলে বট নিজে সিগন্যাল দেবে আর নিজে এন্ট্রি নেবে। শুধু AUTO ENTRY চালু থাকলে তুমি বাটনে চাপলে বিশ্লেষণ করে এন্ট্রি নেবে।"))
        c2.addView(heading("AUTO ENTRY শুধু এর বেশি % হলে").apply { setPadding(0, dp(12), 0, dp(6)) })
        c2.addView(chipRow(minLabels, minBtns) { i -> prefs.edit().putInt("entry_min", minValues[i]).apply(); refresh() })
        c2.addView(note("ANY = প্রতিটা সিগন্যালে এন্ট্রি নেবে।"))
        c2.addView(heading("সিগন্যাল বাছাই: ব্যাকটেস্ট সর্বনিম্ন").apply { setPadding(0, dp(12), 0, dp(6)) })
        c2.addView(chipRow(accLabels, accBtns) { i -> prefs.edit().putInt("min_acc", accValues[i]).apply(); refresh() })
        c2.addView(note("বট শুধু তখনই CALL/PUT দেয় যখন চার্টের আগের ক্যান্ডেলে সবচেয়ে ভালো লজিক এই % এর বেশি ঠিক ছিল, অন্য লজিকও একমত, আর কোনোটা দ্বিমত করছে না। নইলে WAIT। বেশি % দিলে সিগন্যাল কমে। এটা আগের ক্যান্ডেলের হিসাব, জেতার নিশ্চিত সম্ভাবনা নয়। আসল জয়ের হার RESULTS ট্যাবে দেখো।"))
        c2.addView(heading("WAIT সীমা: প্রতি ১০ বিশ্লেষণে সর্বোচ্চ").apply { setPadding(0, dp(12), 0, dp(6)) })
        c2.addView(chipRow(waitLabels, waitBtns) { i -> prefs.edit().putInt("max_wait", waitValues[i]).apply(); refresh() })
        c2.addView(note("১০টার মধ্যে এত বারের বেশি WAIT এলে বট পরেরটায় সবচেয়ে ভালো লজিকের দিকটা দুর্বল সিগন্যাল হিসেবে দেয় (কার্ডে ⚠ চিহ্ন থাকে)। ∞ = কখনো জোর করবে না। কম WAIT মানে বেশি সিগন্যাল, কিন্তু সব সিগন্যাল সমান ভালো না।"))
        val s6 = switchRow("AUTO ENTRY: দুর্বল (forced) সিগন্যাল বাদ", "চালু থাকলে ⚠ চিহ্নের দুর্বল সিগন্যালে অটো এন্ট্রি নেবে না, শুধু দেখাবে।") { on ->
            prefs.edit().putBoolean("skip_forced", on).apply()
        }
        swSkip = s6.second
        c2.addView(s6.first)
        c2.addView(styledButton("ACCESSIBILITY চালু করো (AUTO ENTRY এর জন্য)", Color.parseColor("#1A2A44"), CYAN).apply {
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(12) })
        c2.addView(note("Android ১৩+ এ \"Restricted setting\" দেখালে: ফোনের Settings → Apps → Sahan Ai Elite → ⋮ → Allow restricted settings।"))
        col.addView(c2, lpCard())

        // রেকর্ড ও ফলাফল
        val c3 = card()
        c3.addView(heading("রেকর্ড ও ফলাফল"))
        val s3 = switchRow("SCREEN RECORD", "অন করলে স্ক্রিন ভিডিও রেকর্ড হবে (START করা থাকতে হবে)। ভিডিও গ্যালারির Movies/SahanAiSmart এ থাকবে।") { on ->
            prefs.edit().putBoolean("record", on).apply()
        }
        swRecord = s3.second
        c3.addView(s3.first)
        val s4 = switchRow("RESULT TRACKING", "প্রতিটা সিগন্যালের এন্ট্রি ও এক্সিট প্রাইস পড়ে নিজে WIN/LOSS/DRAW হিসাব করে জমা রাখে। ভুল হলে RESULTS ট্যাবে হাতে ঠিক করা যায়।") { on ->
            prefs.edit().putBoolean("track", on).apply()
        }
        swTrack = s4.second
        c3.addView(s4.first)
        val s5 = switchRow("SHOW LEVELS", "স্ক্যানের পর চার্টে শক্ত সাপোর্ট/রেজিস্ট্যান্স (কতবার ছুঁয়েছে সহ) ও রাউন্ড লেভেল নীল দাগে ১২ সেকেন্ড দেখাবে।") { on ->
            prefs.edit().putBoolean("levels", on).apply()
        }
        swLevels = s5.second
        c3.addView(s5.first)
        col.addView(c3, lpCard())

        col.addView(note("⚠ সিগন্যাল শুধু বিশ্লেষণ-ভিত্তিক আনুমানিক ধারণা, জেতার নিশ্চয়তা নয়। আগে ডেমো অ্যাকাউন্টে পরীক্ষা করো।"))
        return sv
    }

    /* ---------- ফলাফল ---------- */

    private fun buildResults(): ScrollView {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, dp(14), dp(24)) }
        sv.addView(col)

        val top = card()
        statsText = TextView(this).apply { textSize = 14f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD }
        top.addView(statsText)
        top.addView(note("ফলাফল নিজে হিসাব হয়। ভুল হলে নিচের WIN / LOSS / DRAW বাটনে চেপে ঠিক করো। (হাতে ঠিক করলে ✎ চিহ্ন থাকবে)"))
        top.addView(styledButton("সব মুছে ফেলো", Color.parseColor("#7F1D1D")).apply {
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage("সব ফলাফল মুছে ফেলবে?")
                    .setPositiveButton("হ্যাঁ") { _, _ -> HistoryStore.clear(this@MainActivity); renderResults() }
                    .setNegativeButton("না", null)
                    .show()
            }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)).apply { topMargin = dp(10) })
        col.addView(top, lpCard())

        resultsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(resultsBox)
        return sv
    }

    private fun resultColor(r: String) = when (r) {
        "WIN" -> Color.parseColor("#00E676")
        "LOSS" -> Color.parseColor("#FF5252")
        "DRAW" -> Color.parseColor("#FFD54F")
        "PENDING" -> CYAN
        else -> MUTED
    }

    private fun fmt(v: Double) = if (v == 0.0) "?" else String.format(Locale.US, "%.5f", v).trimEnd('0').trimEnd('.')

    private fun renderResults() {
        val list = HistoryStore.load(this).asReversed()
        val w = list.count { it.result == "WIN" }
        val l = list.count { it.result == "LOSS" }
        val d = list.count { it.result == "DRAW" }
        val rate = if (w + l == 0) 0 else (w * 100 / (w + l))
        val byLogic = LinkedHashMap<String, IntArray>()
        for (e in list) {
            if (e.logic.isEmpty()) continue
            val a = byLogic.getOrPut(e.logic) { IntArray(2) }
            if (e.result == "WIN") a[0]++ else if (e.result == "LOSS") a[1]++
        }
        val logicText = byLogic.entries.filter { it.value[0] + it.value[1] > 0 }
            .sortedByDescending { it.value[0].toDouble() / (it.value[0] + it.value[1]) }
            .joinToString("\n") { "${it.key}: ${it.value[0]}W / ${it.value[1]}L (${it.value[0] * 100 / (it.value[0] + it.value[1])}%)" }
        statsText.text = "Total ${list.size}   WIN $w   LOSS $l   DRAW $d\nWin rate: $rate%" +
                (if (logicText.isNotEmpty()) "\n\nলজিক অনুযায়ী:\n$logicText" else "")
        resultsBox.removeAllViews()
        val tfmt = SimpleDateFormat("HH:mm:ss", Locale.US)
        for (e in list.take(100)) {
            val row = card()
            val up = e.dir == "CALL"
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            head.addView(TextView(this).apply {
                text = "${tfmt.format(Date(e.id))}   ${if (up) "CALL ▲" else "PUT ▼"}   ${if (e.tf >= 60) "${e.tf / 60}m" else "${e.tf}s"}   ${e.conf}%" +
                        (if (e.auto) "   AUTO" else "") + (if (e.logic.isNotEmpty()) "\n${e.logic}" else "")
                textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            head.addView(TextView(this).apply {
                text = e.result + (if (e.fixed) " ✎" else "")
                textSize = 13f; setTextColor(resultColor(e.result)); typeface = Typeface.DEFAULT_BOLD
            })
            row.addView(head)
            row.addView(note("Entry ${fmt(e.entry)}  →  Exit ${fmt(e.exit)}"))
            val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, 0) }
            for (name in listOf("WIN", "LOSS", "DRAW")) {
                btns.addView(styledButton(name, Color.parseColor("#1A2A44"), resultColor(name)).apply {
                    textSize = 11f
                    setOnClickListener {
                        HistoryStore.update(this@MainActivity, e.id) { x -> x.result = name; x.fixed = true }
                        renderResults()
                    }
                }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { leftMargin = dp(3); rightMargin = dp(3) })
            }
            row.addView(btns)
            resultsBox.addView(row, lpCard())
        }
        if (list.isEmpty()) resultsBox.addView(note("এখনো কোনো ফলাফল নেই। AI বাটনে চেপে সিগন্যাল নিলে এখানে জমা হবে।"), lpCard())
    }

    private fun showTab(results: Boolean) {
        resultsVisible = results
        settingsView.visibility = if (results) View.GONE else View.VISIBLE
        resultsView.visibility = if (results) View.VISIBLE else View.GONE
        styleChips(listOf(tabSettings, tabResults), if (results) 1 else 0)
        ui.removeCallbacks(refresher)
        if (results) ui.post(refresher)
    }

    private fun refresh() {
        styleChips(tfBtns, prefs.getInt("tf", 0).coerceIn(0, 3))
        val mn = prefs.getInt("entry_min", 0)
        styleChips(minBtns, minValues.indexOf(mn).let { if (it < 0) 0 else it })
        styleChips(accBtns, accValues.indexOf(prefs.getInt("min_acc", 80)).let { if (it < 0) 2 else it })
        swSignal.isChecked = prefs.getBoolean("auto_signal", false)
        swEntry.isChecked = prefs.getBoolean("auto_entry", false)
        swRecord.isChecked = prefs.getBoolean("record", false)
        swTrack.isChecked = prefs.getBoolean("track", true)
        swLevels.isChecked = prefs.getBoolean("levels", true)
        swSkip.isChecked = prefs.getBoolean("skip_forced", true)
        styleChips(waitBtns, waitValues.indexOf(prefs.getInt("max_wait", 3)).let { if (it < 0) 1 else it })
    }

    /* ---------- START ---------- */

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "অন্য অ্যাপের উপর দেখানোর পারমিশন দাও", Toast.LENGTH_LONG).show()
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                REQ_OVERLAY
            )
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_OVERLAY -> if (Settings.canDrawOverlays(this)) start()
            REQ_CAPTURE -> if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, OverlayService::class.java)
                    .putExtra(OverlayService.EXTRA_CODE, resultCode)
                    .putExtra(OverlayService.EXTRA_DATA, data)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "স্ক্রিন ক্যাপচার পারমিশন লাগবে", Toast.LENGTH_LONG).show()
            }
        }
    }
}
