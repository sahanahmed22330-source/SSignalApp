# Sahan Ai Smart
Finds which logic the market is currently following (trend, reversion, streak, fade, wick, pattern, breakout, bounce, MACD, zigzag, combo)
by back-testing every logic on the visible candles, then signals with the best-performing one. Auto Signal / Auto Entry, result tracking,
screen record. Analysis only - no signal is guaranteed.
