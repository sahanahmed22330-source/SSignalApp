/*
 * S SIGNAL  -  Floating chart-analysis overlay (single file, Kotlin, no external libraries)
 *
 * কী করে:
 *  1) ফ্লোটিং "S" লোগো স্ক্রিনের উপর ভাসে (ড্র্যাগ করা যায়, ট্যাপ করলে প্যানেল খোলে)
 *  2) MediaProjection দিয়ে স্ক্রিন ক্যাপচার করে চার্টের ক্যান্ডেল (সবুজ/লাল) পড়ে
 *  3) RSI (Wilder) + MACD + EMA ট্রেন্ড + ক্যান্ডেল মোমেন্টাম + সাপোর্ট/রেজিস্ট্যান্স মিলিয়ে
 *     মাল্টিপল কনফার্মেশনে CALL / PUT / WAIT সিগন্যাল দেয়
 *  4) চার্টের উপর নীল (BLUE) দাগ টানে: সাপোর্ট, রেজিস্ট্যান্স, শেষ প্রাইস
 *  5) স্ক্রিন রেকর্ড (MP4) করা যায়
 *
 * গুরুত্বপূর্ণ: এটা একটি সম্ভাবনা-নির্ভর টেকনিক্যাল বিশ্লেষণ টুল। কোনো সিগন্যালই নিশ্চিত নয়।
 * Binary/OTC ট্রেডিংয়ে পুরো টাকা হারানোর ঝুঁকি আছে।
 *
 * ---------------------------------------------------------------------------
 * SETUP (Android Studio):
 *  - New Project > Empty Views Activity (Kotlin), package: com.sahan.aisignal
 *  - minSdk 26, compileSdk/targetSdk 34
 *  - এই ফাইলটা app/src/main/java/com/sahan/aisignal/SSignal.kt এ রাখো
 *    (MainActivity.kt ফাইলটা মুছে দাও)
 *  - AndroidManifest.xml এ নিচেরটা বসাও:
 *
 *  <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
 *  <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
 *  <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION"/>
 *  <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
 *
 *  <application android:label="S Signal" android:icon="@mipmap/ic_launcher"
 *               android:theme="@android:style/Theme.DeviceDefault.NoActionBar">
 *      <activity android:name=".MainActivity" android:exported="true">
 *          <intent-filter>
 *              <action android:name="android.intent.action.MAIN"/>
 *              <category android:name="android.intent.category.LAUNCHER"/>
 *          </intent-filter>
 *      </activity>
 *      <service android:name=".OverlayService" android:exported="false"
 *               android:foregroundServiceType="mediaProjection"/>
 *  </application>
 * ---------------------------------------------------------------------------
 */
package com.sahan.aisignal

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.animation.ValueAnimator
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Switch
import android.widget.Toast
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/* =============================================================================
 *  DATA MODELS
 * ========================================================================== */

data class Candle(
    val open: Double, val high: Double, val low: Double, val close: Double, val x: Float
) {
    val bullish get() = close > open
}

enum class Direction { CALL, PUT, WAIT }

data class SignalResult(
    val direction: Direction,
    val confidence: Int,          // আনুমানিক সম্ভাবনা % (সর্বোচ্চ ~71, নিশ্চয়তা নয়)
    val score: Int,               // -9 .. +9
    val confirmations: Int,       // কয়টা ইন্ডিকেটর একই দিকে
    val rsi: Double,
    val macdHist: Double,
    val trend: String,
    val candleCount: Int,
    val note: String,
    val supportY: Float? = null,
    val resistanceY: Float? = null,
    val lastY: Float? = null
)

/* =============================================================================
 *  INDICATORS  (RSI, EMA, MACD)
 * ========================================================================== */

object Indicators {

    /** Exponential Moving Average */
    fun ema(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val k = 2.0 / (period + 1)
        val out = ArrayList<Double>(values.size)
        var prev = values[0]
        out.add(prev)
        for (i in 1 until values.size) {
            prev = values[i] * k + prev * (1 - k)
            out.add(prev)
        }
        return out
    }

    /** RSI - Wilder's smoothing. রিটার্ন লিস্টের দৈর্ঘ্য = closes.size - period */
    fun rsi(closes: List<Double>, period: Int = 14): List<Double> {
        if (closes.size <= period) return emptyList()
        var gain = 0.0
        var loss = 0.0
        for (i in 1..period) {
            val d = closes[i] - closes[i - 1]
            if (d >= 0) gain += d else loss -= d
        }
        var avgGain = gain / period
        var avgLoss = loss / period
        val out = ArrayList<Double>()
        fun value(): Double =
            if (avgLoss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + avgGain / avgLoss)
        out.add(value())
        for (i in period + 1 until closes.size) {
            val d = closes[i] - closes[i - 1]
            val g = max(d, 0.0)
            val l = max(-d, 0.0)
            avgGain = (avgGain * (period - 1) + g) / period
            avgLoss = (avgLoss * (period - 1) + l) / period
            out.add(value())
        }
        return out
    }

    data class Macd(val line: List<Double>, val signal: List<Double>, val hist: List<Double>)

    /** MACD = EMA(fast) - EMA(slow);  Signal = EMA(MACD, signalPeriod);  Hist = MACD - Signal */
    fun macd(closes: List<Double>, fast: Int = 12, slow: Int = 26, signalP: Int = 9): Macd {
        val ef = ema(closes, fast)
        val es = ema(closes, slow)
        val line = closes.indices.map { ef[it] - es[it] }
        val sig = ema(line, signalP)
        val hist = line.indices.map { line[it] - sig[it] }
        return Macd(line, sig, hist)
    }
}

/* =============================================================================
 *  CHART READER  (স্ক্রিনশট থেকে সবুজ/লাল ক্যান্ডেল বের করা)
 * ========================================================================== */

object ChartReader {

    private const val MIN_PIXELS = 6      // একটা কলামে কমপক্ষে এতগুলো রঙিন পিক্সেল
    private const val MIN_WIDTH = 3       // ক্যান্ডেলের ন্যূনতম প্রস্থ (পিক্সেল)

    private fun isGreen(r: Int, g: Int, b: Int) = g > 140 && g > r + 60 && g > b + 60
    private fun isRed(r: Int, g: Int, b: Int) = r > 170 && r > g + 80 && r > b + 70

    /**
     * চার্ট এলাকা নিজে খুঁজে নেয়: উপরে হেডারের নিচ থেকে, নিচে BUY/SELL প্যানেলের উপর পর্যন্ত।
     * BUY/SELL বাটন (বড় সবুজ+লাল ব্লক) না পেলে ডিফল্ট ৭৩% ব্যবহার করে।
     */
    fun autoRegion(bmp: Bitmap): Pair<Int, Int> {
        val w = bmp.width
        val h = bmp.height
        val top = (h * 0.12f).toInt()
        var bottom = (h * 0.73f).toInt()
        val row = IntArray(w)
        var run = 0
        var y = (h * 0.80f).toInt()
        while (y < h) {
            bmp.getPixels(row, 0, w, 0, y, w, 1)
            var cnt = 0
            var samples = 0
            var x = 0
            while (x < w) {
                val p = row[x]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                if (isGreen(r, g, b) || isRed(r, g, b)) cnt++
                samples++
                x += 3
            }
            if (cnt >= samples * 0.40) run++ else run = 0
            if (run >= 8) {
                val bandTop = y - 2 * 7
                bottom = (bandTop - h * 0.155f).toInt().coerceIn((h * 0.50f).toInt(), (h * 0.85f).toInt())
                break
            }
            y += 2
        }
        return top to bottom
    }

    /**
     * bmp এর [regionTop, regionBottom) এলাকায় ক্যান্ডেল খোঁজে।
     * প্রাইস = (এলাকার উচ্চতা - y), অর্থাৎ উপরে গেলে প্রাইস বাড়ে (আপেক্ষিক স্কেল)।
     */
    fun detect(bmp: Bitmap, regionTop: Int, regionBottom: Int): List<Candle> {
        val w = bmp.width
        val h = regionBottom - regionTop
        if (h <= 10) return emptyList()
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, regionTop, w, h)

        val type = IntArray(w)                   // 0 = কিছু নেই, 1 = সবুজ, 2 = লাল
        val colMin = IntArray(w) { Int.MAX_VALUE }
        val colMax = IntArray(w) { -1 }

        for (x in 0 until w) {
            var gc = 0; var gMin = Int.MAX_VALUE; var gMax = -1
            var rc = 0; var rMin = Int.MAX_VALUE; var rMax = -1
            for (y in 0 until h) {
                val p = px[y * w + x]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                if (isGreen(r, g, b)) {
                    gc++; if (y < gMin) gMin = y; if (y > gMax) gMax = y
                } else if (isRed(r, g, b)) {
                    rc++; if (y < rMin) rMin = y; if (y > rMax) rMax = y
                }
            }
            if (gc >= MIN_PIXELS && gc >= rc) {
                type[x] = 1; colMin[x] = gMin; colMax[x] = gMax
            } else if (rc >= MIN_PIXELS) {
                type[x] = 2; colMin[x] = rMin; colMax[x] = rMax
            }
        }

        val candles = ArrayList<Candle>()
        var x = 0
        while (x < w) {
            if (type[x] == 0) { x++; continue }
            val t = type[x]
            var end = x
            while (end + 1 < w && type[end + 1] == t) end++
            val width = end - x + 1
            if (width >= MIN_WIDTH) {
                val mins = ArrayList<Int>()
                val maxs = ArrayList<Int>()
                var hi = Int.MAX_VALUE
                var lo = -1
                for (cx in x..end) {
                    mins.add(colMin[cx]); maxs.add(colMax[cx])
                    if (colMin[cx] < hi) hi = colMin[cx]
                    if (colMax[cx] > lo) lo = colMax[cx]
                }
                mins.sort(); maxs.sort()
                val bodyTop = mins[mins.size / 2]       // median => উইক বাদ পড়ে, বডি থাকে
                val bodyBottom = maxs[maxs.size / 2]
                fun price(y: Int) = (h - y).toDouble()
                val open: Double
                val close: Double
                if (t == 1) { open = price(bodyBottom); close = price(bodyTop) }
                else        { open = price(bodyTop);    close = price(bodyBottom) }
                candles.add(Candle(open, price(hi), price(lo), close, (x + end) / 2f))
            }
            x = end + 1
        }
        return candles
    }
}

/* =============================================================================
 *  SIGNAL ENGINE  (মাল্টিপল কনফার্মেশন)
 * ========================================================================== */

object SignalEngine {

    fun analyze(candles: List<Candle>, regionTop: Int, regionH: Int, liveDelta: Double = 0.0, sensitivity: Int = 1): SignalResult {
        val n = candles.size
        if (n < 12) {
            return SignalResult(
                Direction.WAIT, 0, 0, 0, 0.0, 0.0, "-", n,
                "মাত্র $n টা ক্যান্ডেল পাওয়া গেছে (কমপক্ষে ১২ লাগবে). চার্ট এলাকা ঠিক করো বা জুম আউট করো।"
            )
        }

        val closes = candles.map { it.close }
        // ক্যান্ডেল কম হলে দ্রুত (adaptive) পিরিয়ড
        val quick = n < 35
        val rsiP = if (quick) 7 else 14
        val emaF = if (quick) 5 else 9
        val emaS = if (quick) 13 else 21
        val mF = if (quick) 5 else 12
        val mS = if (quick) 13 else 26
        val mG = if (quick) 4 else 9

        val rsiList = Indicators.rsi(closes, rsiP)
        val macd = Indicators.macd(closes, mF, mS, mG)
        val eF = Indicators.ema(closes, emaF)
        val eS = Indicators.ema(closes, emaS)

        val rsi = rsiList.last()
        val rsiPrev = if (rsiList.size > 1) rsiList[rsiList.size - 2] else rsi
        val hist = macd.hist.last()
        val histPrev = macd.hist[macd.hist.size - 2]

        // ---- ১) RSI ভোট ----
        val rsiVote = when {
            rsi < 30 -> +2
            rsi < 45 && rsi > rsiPrev -> +1
            rsi > 70 -> -2
            rsi > 55 && rsi < rsiPrev -> -1
            rsi in 50.0..70.0 && rsi >= rsiPrev -> +1     // বুলিশ মোমেন্টাম
            rsi in 30.0..50.0 && rsi <= rsiPrev -> -1     // বেয়ারিশ মোমেন্টাম
            else -> 0
        }

        // ---- ২) MACD ভোট ----
        val macdVote = when {
            histPrev <= 0 && hist > 0 -> +2          // বুলিশ ক্রস
            histPrev >= 0 && hist < 0 -> -2          // বেয়ারিশ ক্রস
            hist > 0 && hist > histPrev -> +1
            hist < 0 && hist < histPrev -> -1
            else -> 0
        }

        // ---- ৩) EMA ট্রেন্ড ভোট ----
        val hi = candles.maxOf { it.high }
        val lo = candles.minOf { it.low }
        val range = max(hi - lo, 1.0)
        val gap = eF.last() - eS.last()
        val emaVote = when {
            abs(gap) < range * 0.01 -> 0              // সাইডওয়েজ
            gap > 0 -> +1
            else -> -1
        }
        val trend = when (emaVote) { 1 -> "UP"; -1 -> "DOWN"; else -> "SIDEWAYS" }

        // ---- ৪) ক্যান্ডেল মোমেন্টাম (শেষ ৩ ক্যান্ডেল) ----
        val last3 = candles.takeLast(3)
        val candleVote = when {
            last3.all { it.bullish } -> +1
            last3.none { it.bullish } -> -1
            else -> 0
        }

        // ---- ৫) সাপোর্ট / রেজিস্ট্যান্স ----
        val last = closes.last()
        val srVote = when {
            last <= lo + range * 0.08 -> +1           // সাপোর্টের কাছে
            last >= hi - range * 0.08 -> -1           // রেজিস্ট্যান্সের কাছে
            else -> 0
        }

        // ---- ৬) লাইভ মোমেন্টাম (বিশ্লেষণের ৩-৫ সেকেন্ডে চলমান ক্যান্ডেলের দিক) ----
        val momVote = when {
            liveDelta > range * 0.02 -> +1
            liveDelta < -range * 0.02 -> -1
            else -> 0
        }

        val votes = listOf(rsiVote, macdVote, emaVote, candleVote, srVote, momVote)
        val score = votes.sum()
        val sign = if (score > 0) 1 else if (score < 0) -1 else 0
        val confirms = if (sign == 0) 0 else votes.count { it * sign > 0 }

        // কখনো WAIT নয়: স্কোর যেদিকে সেদিকে সিগন্যাল। স্কোর ০ হলে EMA, না হলে শেষ ক্যান্ডেলের দিক।
        // % যত বেশি সিগন্যাল তত শক্ত, ৫০-৫৩% মানে দুর্বল।
        val dir = when {
            score > 0 -> Direction.CALL
            score < 0 -> Direction.PUT
            gap > 0 -> Direction.CALL
            gap < 0 -> Direction.PUT
            candles.last().bullish -> Direction.CALL
            else -> Direction.PUT
        }
        val confidence = 50 + min(abs(score), 7) * 3

        fun toScreenY(price: Double) = regionTop + (regionH - price).toFloat()

        val note = when (dir) {
            Direction.CALL -> "$confirms/6 ইন্ডিকেটর বুলিশ."
            Direction.PUT -> "$confirms/6 ইন্ডিকেটর বেয়ারিশ."
            Direction.WAIT -> "পর্যাপ্ত কনফার্মেশন নেই — অপেক্ষা করো."
        } + if (quick) " (দ্রুত মোড: ক্যান্ডেল কম)" else ""

        return SignalResult(
            dir, confidence, score, confirms, rsi, hist, trend, n, note,
            // চার্ট এলাকার কিনারায় কেটে যাওয়া ক্যান্ডেল থেকে সাপোর্ট/রেজিস্ট্যান্স আঁকা ভুল হয়, তাই বাদ
            supportY = if (lo > 18) toScreenY(lo) else null,
            resistanceY = if (hi < regionH - 18) toScreenY(hi) else null,
            lastY = if (last > 18 && last < regionH - 18) toScreenY(last) else null
        )
    }
}

/* =============================================================================
 *  VIEWS  (S লোগো + নীল দাগের ওভারলে)
 * ========================================================================== */

private fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

class LogoView(ctx: Context) : View(ctx) {
    var status = "WAITING"
        set(value) { field = value; invalidate() }
    var statusColor = Color.parseColor("#00E676")
        set(value) { field = value; invalidate() }

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2061A1C") }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00F5D4"); style = Paint.Style.STROKE; strokeWidth = ctx.dp(3).toFloat()
    }
    private val letter = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B9FFE6"); textSize = ctx.dp(38).toFloat(); typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = ctx.dp(9).toFloat(); typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val tagBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2050E10") }
    private val tagStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E676"); style = Paint.Style.STROKE; strokeWidth = ctx.dp(1).toFloat()
    }
    private val tagText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E676"); textSize = ctx.dp(9).toFloat(); typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(c: Canvas) {
        val d = ctx().dp(1).toFloat()
        val side = width - 12f
        val badge = RectF(6f, 6f, 6f + side, 6f + side)
        c.drawRoundRect(badge, 16 * d, 16 * d, bg)
        c.drawRoundRect(badge, 16 * d, 16 * d, stroke)
        c.drawText("S", width / 2f, badge.top + side * 0.60f, letter)
        small.color = statusColor
        c.drawText(status, width / 2f, badge.bottom - 9 * d, small)

        val tag = RectF(4f, badge.bottom + 8 * d, width - 4f, badge.bottom + 28 * d)
        c.drawRoundRect(tag, 3 * d, 3 * d, tagBg)
        c.drawRoundRect(tag, 3 * d, 3 * d, tagStroke)
        c.drawText("S SIGNAL", width / 2f, tag.centerY() + 3.5f * d, tagText)
    }

    private fun ctx() = context
}

/** বিশ্লেষণের সময় চার্টের উপর দিয়ে ওঠানামা করা নীল স্ক্যান লাইন */
class ScanView(ctx: Context) : View(ctx) {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2979FF"); strokeWidth = ctx.dp(3).toFloat()
    }
    private val glow = Paint()
    private val dim = Paint().apply { color = 0x33000000 }
    private var top = 0
    private var bottom = 0
    private var pos = 0f
    private var anim: ValueAnimator? = null

    fun begin(t: Int, b: Int) {
        top = t; bottom = b
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener { pos = it.animatedValue as Float; invalidate() }
            start()
        }
        visibility = VISIBLE
    }

    fun end() {
        anim?.cancel(); anim = null
        visibility = GONE
    }

    override fun onDraw(c: Canvas) {
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)      // স্ক্রিন একটু অন্ধকার
        val y = top + (bottom - top) * pos
        val h = context.dp(46).toFloat()
        glow.shader = LinearGradient(
            0f, y - h, 0f, y + h,
            intArrayOf(0x002979FF, 0x662979FF, 0x002979FF),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, y - h, width.toFloat(), y + h, glow)
        c.drawLine(0f, y, width.toFloat(), y, line)
    }
}

/* =============================================================================
 *  MAIN ACTIVITY  (সব সেটিংস এখানে + START/STOP)
 * ========================================================================== */

class MainActivity : Activity() {

    private val REQ_OVERLAY = 101
    private val REQ_CAPTURE = 102
    private val prefs by lazy { getSharedPreferences("s_signal", Context.MODE_PRIVATE) }

    private val tfLabels = listOf("5s", "10s", "15s", "30s", "1m")
    private val minLabels = listOf("50%", "55%", "60%", "65%")
    private val minValues = listOf(50, 55, 60, 65)
    private val capLabels = listOf("5", "10", "20", "∞")
    private val capValues = listOf(5, 10, 20, 0)

    private val tfBtns = ArrayList<Button>()
    private val minBtns = ArrayList<Button>()
    private val capBtns = ArrayList<Button>()
    private lateinit var swSignal: Switch
    private lateinit var swEntry: Switch
    private lateinit var swRecord: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(24))
        }
        val sv = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0B1220")) }
        sv.addView(root)

        root.addView(TextView(this).apply {
            text = "S"; textSize = 56f; setTextColor(Color.parseColor("#00E5FF"))
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        })
        root.addView(title("S SIGNAL", 18f, Color.WHITE, Gravity.CENTER))

        val startRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        startRow.addView(Button(this).apply { text = "START"; setOnClickListener { start() } },
            LinearLayout.LayoutParams(0, dp(52), 1f))
        startRow.addView(Button(this).apply {
            text = "STOP"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(startRow)
        root.addView(hint("START চেপে পারমিশন দিয়ে ট্রেডিং অ্যাপ খোলো। চার্টের উপর S বাটনে ট্যাপ করলেই মার্কেট স্ক্যান হয়ে সিগন্যাল আসবে। বাটন ধরে রাখলে স্ক্রিন রেকর্ড শুরু/বন্ধ হবে।"))

        root.addView(title("সিগন্যাল কোন টাইমের ক্যান্ডেলের জন্য", 13f, Color.parseColor("#90A4AE")))
        root.addView(chipRow(tfLabels, tfBtns) { i -> prefs.edit().putInt("tf", i).apply(); refresh() })
        root.addView(hint("প্ল্যাটফর্মেও একই টাইমফ্রেম রাখো। ক্যান্ডেল শেষ হওয়ার ৫-৬ সেকেন্ড আগে S বাটনে চাপো।"))

        root.addView(hint("সিগন্যাল সবসময় CALL বা PUT আসবে। % যত বেশি সিগন্যাল তত শক্ত, ৫০-৫৩% মানে খুব দুর্বল।"))

        swSignal = Switch(this).apply {
            text = "AUTO SIGNAL (নিজে নিজে বারবার সিগন্যাল)"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("auto_signal", on).apply() }
        }
        root.addView(swSignal, space())

        swRecord = Switch(this).apply {
            text = "SCREEN RECORD (গ্যালারি → Movies/SSignal)"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("record", on).apply() }
        }
        root.addView(swRecord, space())

        swEntry = Switch(this).apply {
            text = "AUTO ENTRY (নিজে BUY/SELL চাপবে)"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { b, on ->
                if (on && !entryReady()) {
                    b.isChecked = false
                } else {
                    prefs.edit().putBoolean("auto_entry", on).apply()
                }
            }
        }
        root.addView(swEntry, space())

        root.addView(title("AUTO ENTRY সীমা (প্রতিবার চালুর পর)", 13f, Color.parseColor("#90A4AE")))
        root.addView(chipRow(capLabels, capBtns) { i -> prefs.edit().putInt("entry_cap", capValues[i]).apply(); refresh() })

        root.addView(title("AUTO ENTRY শুধু এর বেশি % হলে", 13f, Color.parseColor("#90A4AE")))
        root.addView(chipRow(minLabels, minBtns) { i -> prefs.edit().putInt("entry_min", minValues[i]).apply(); refresh() })

        val setupRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        setupRow.addView(Button(this).apply {
            text = "ACCESSIBILITY"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        setupRow.addView(Button(this).apply {
            text = "CALIBRATE"
            setOnClickListener {
                startService(Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_CALIBRATE))
                moveTaskToBack(true)
            }
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(setupRow, space())
        root.addView(hint("AUTO ENTRY এর আগে: ১) ACCESSIBILITY এ S Signal অন করো  ২) ট্রেডিং অ্যাপ খুলে CALIBRATE চেপে BUY ও SELL বাটনে একবার করে ট্যাপ করো।"))

        root.addView(hint("⚠ সিগন্যাল শুধু আনুমানিক সম্ভাবনা, নিশ্চয়তা নয়। আগে ডেমোতে পরীক্ষা করো।"))
        setContentView(sv)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun entryReady(): Boolean {
        if (!prefs.contains("bx") || !prefs.contains("sx")) {
            Toast.makeText(this, "আগে CALIBRATE করে BUY ও SELL বাটন চিনিয়ে দাও", Toast.LENGTH_LONG).show(); return false
        }
        if (TapService.instance == null) {
            Toast.makeText(this, "ACCESSIBILITY এ S Signal চালু করো", Toast.LENGTH_LONG).show(); return false
        }
        return true
    }

    private fun refresh() {
        val tf = prefs.getInt("tf", 1)
        val mn = prefs.getInt("entry_min", 55)
        val cap = prefs.getInt("entry_cap", 5)
        tfBtns.forEachIndexed { i, b -> b.text = if (i == tf) "✔ ${tfLabels[i]}" else tfLabels[i] }
        minBtns.forEachIndexed { i, b -> b.text = if (minValues[i] == mn) "✔ ${minLabels[i]}" else minLabels[i] }
        swRecord.isChecked = prefs.getBoolean("record", false)
        capBtns.forEachIndexed { i, b -> b.text = if (capValues[i] == cap) "✔ ${capLabels[i]}" else capLabels[i] }
        swSignal.isChecked = prefs.getBoolean("auto_signal", false)
        swEntry.isChecked = prefs.getBoolean("auto_entry", false)
    }

    private fun chipRow(labels: List<String>, store: MutableList<Button>, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        labels.forEachIndexed { i, t ->
            val b = Button(this).apply { text = t; textSize = 12f; isAllCaps = false; setOnClickListener { onPick(i) } }
            store.add(b)
            row.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        return row
    }

    private fun title(t: String, size: Float, color: Int, g: Int = Gravity.START) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); gravity = g; typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(14), 0, dp(4))
    }

    private fun hint(t: String) = TextView(this).apply {
        text = t; textSize = 11f; setTextColor(Color.parseColor("#78909C")); setPadding(0, dp(4), 0, dp(4))
    }

    private fun space() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(10) }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "অন্য অ্যাপের উপর দেখানোর পারমিশন দাও", Toast.LENGTH_LONG).show()
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                REQ_OVERLAY
            )
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)   // স্ক্রিন ক্যাপচার পারমিশন
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_OVERLAY -> if (Settings.canDrawOverlays(this)) start()
            REQ_CAPTURE -> if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, OverlayService::class.java)
                    .putExtra(OverlayService.EXTRA_CODE, resultCode)
                    .putExtra(OverlayService.EXTRA_DATA, data)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "স্ক্রিন ক্যাপচার পারমিশন লাগবে", Toast.LENGTH_LONG).show()
            }
        }
    }
}

/* =============================================================================
 *  TAP SERVICE  (Accessibility - অটো এন্ট্রির জন্য স্ক্রিনে ট্যাপ করে)
 * ========================================================================== */

class TapService : AccessibilityService() {
    companion object {
        @Volatile var instance: TapService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesture, null, null)
    }
}

/* =============================================================================
 *  OVERLAY SERVICE  (S বাটন + পপআপ + স্ক্যান + সিগন্যাল)
 * ========================================================================== */

class OverlayService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_CALIBRATE = "com.sahan.aisignal.CALIBRATE"
        private const val CHANNEL = "s_signal_channel"
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private val prefs by lazy { getSharedPreferences("s_signal", Context.MODE_PRIVATE) }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var captureDisplay: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var recDisplay: VirtualDisplay? = null
    private var recording = false

    private var sw = 0
    private var sh = 0
    private var dpi = 0

    private lateinit var root: LinearLayout
    private lateinit var rootLp: WindowManager.LayoutParams
    private lateinit var logo: LogoView
    private lateinit var closeBtn: TextView
    private lateinit var popupBox: LinearLayout
    private lateinit var scanView: ScanView

    private val tfLabels = listOf("5s", "10s", "15s", "30s", "1m")
    private val tfSecs = listOf(5, 10, 15, 30, 60)

    private var busy = false
    private var autoCount = 0
    private var lastDir = Direction.WAIT
    private var analyzingPill: View? = null

    @Volatile private var lastBmp: Bitmap? = null
    @Volatile private var lastBmpAt = 0L
    private var lastConvertAt = 0L

    private fun tfIndex() = prefs.getInt("tf", 1).coerceIn(0, 4)
    private fun tfSec() = tfSecs[tfIndex()]
    private fun analysisSec() = if (tfSec() <= 10) 3 else 4                 // ৩-৪ সেকেন্ড স্ক্যান
    private fun cycleMs() = max(tfSec(), analysisSec() + 3) * 1000L

    private val autoLoop = object : Runnable {
        override fun run() {
            if (prefs.getBoolean("auto_signal", false)) {
                if (!busy) analyzeNow()
                ui.postDelayed(this, cycleMs())
            }
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            "auto_signal" -> {
                ui.removeCallbacks(autoLoop)
                if (prefs.getBoolean("auto_signal", false)) ui.post(autoLoop)
            }
            "auto_entry" -> autoCount = 0
            "record" -> if (prefs.getBoolean("record", false)) startRecord() else stopRecord()
            else -> {}
        }
    }

    private var tickerStart = 0L
    private var tickerTotal = 0L
    private val ticker = object : Runnable {
        override fun run() {
            if (!busy) return
            val left = max(0L, tickerTotal - (SystemClock.uptimeMillis() - tickerStart))
            logo.status = String.format(Locale.US, "%.1fs", left / 1000.0)
            ui.postDelayed(this, 100)
        }
    }

    private val logoReset = Runnable { if (!busy) { logo.status = "WAITING"; logo.statusColor = Color.parseColor("#00E676") } }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CALIBRATE) {
            if (projection != null) calibrate() else { toast("আগে START চাপো"); stopSelf() }
            return START_NOT_STICKY
        }
        startForegroundCompat()
        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        if (projection == null) {
            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            setupScreenMetrics()
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mpm.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { ui.post { stopSelf() } }
            }, ui)
            // নিরাপত্তা: সার্ভিস চালুর সময় অটো ফিচার বন্ধ থেকে শুরু হয়
            prefs.edit().putBoolean("auto_signal", false).putBoolean("auto_entry", false).putBoolean("record", false).apply()
            prefs.registerOnSharedPreferenceChangeListener(prefListener)
            setupCapture()
            buildOverlay()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "S Signal", NotificationManager.IMPORTANCE_LOW))
        }
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this))
            .setContentTitle("S Signal চলছে")
            .setContentText("S বাটনে ট্যাপ করলে মার্কেট স্ক্যান হবে")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun setupScreenMetrics() {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        sw = m.widthPixels; sh = m.heightPixels; dpi = m.densityDpi
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    /* ---------------- স্ক্রিন ক্যাপচার ---------------- */

    private fun setupCapture() {
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        reader = r
        captureDisplay = projection?.createVirtualDisplay(
            "S_capture", sw, sh, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = SystemClock.uptimeMillis()
                if (now - lastConvertAt >= 300) {
                    lastConvertAt = now
                    val plane = img.planes[0]
                    val rowPad = plane.rowStride - plane.pixelStride * sw
                    val full = Bitmap.createBitmap(sw + rowPad / plane.pixelStride, sh, Bitmap.Config.ARGB_8888)
                    full.copyPixelsFromBuffer(plane.buffer)
                    val bmp = if (rowPad == 0) full else Bitmap.createBitmap(full, 0, 0, sw, sh)
                    lastBmp = bmp
                    lastBmpAt = SystemClock.uptimeMillis()
                }
            } catch (_: Exception) {
            } finally {
                img.close()
            }
        }, ui)
    }

    /** কমপক্ষে ০.৩৫ সেকেন্ড পরের একটি নতুন ফ্রেম (ওভারলে লুকানোর পরের পরিষ্কার ছবি) */
    private fun waitFreshFrame(): Bitmap? {
        val t0 = SystemClock.uptimeMillis()
        while (SystemClock.uptimeMillis() - t0 < 2500) {
            val b = lastBmp
            if (b != null && lastBmpAt >= t0 + 350) return b
            Thread.sleep(40)
        }
        return lastBmp
    }

    /* ---------------- ওভারলে UI ---------------- */

    private fun overlayParams(w: Int, h: Int, flags: Int, gravity: Int, x: Int = 0, y: Int = 0) =
        WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).also { it.gravity = gravity; it.x = x; it.y = y }

    private fun buildOverlay() {
        // স্ক্যান লেয়ার (টাচ ধরে না)
        scanView = ScanView(this)
        scanView.visibility = View.GONE
        wm.addView(
            scanView,
            overlayParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                Gravity.TOP or Gravity.START
            )
        )

        // S বাটন + X বাটন + পপআপ বক্স
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val topRow = FrameLayout(this)
        logo = LogoView(this)
        topRow.addView(logo, FrameLayout.LayoutParams(dp(84), dp(112), Gravity.CENTER_HORIZONTAL))
        closeBtn = TextView(this).apply {
            text = "✕"; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#B3424A55")) }
            visibility = View.GONE
            setOnClickListener { removeLastPopup() }
        }
        topRow.addView(closeBtn, FrameLayout.LayoutParams(dp(38), dp(38), Gravity.END or Gravity.TOP).apply {
            topMargin = dp(22); rightMargin = dp(16)
        })
        root.addView(topRow, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        popupBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        root.addView(popupBox, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        rootLp = overlayParams(
            dp(300), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            Gravity.TOP or Gravity.START, max(0, (sw - dp(300)) / 2), dp(70)
        )

        // S বাটন: ট্যাপ = স্ক্যান, টেনে সরানো, ধরে রাখলে স্ক্রিন রেকর্ড
        logo.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false; var longFired = false
            val longPress = Runnable { longFired = true; toggleRecord() }
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = rootLp.x; sy = rootLp.y; tx = e.rawX; ty = e.rawY; moved = false; longFired = false
                        ui.postDelayed(longPress, 900)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) { moved = true; ui.removeCallbacks(longPress) }
                        if (moved) {
                            rootLp.x = sx + dx; rootLp.y = sy + dy
                            wm.updateViewLayout(root, rootLp)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        ui.removeCallbacks(longPress)
                        if (!moved && !longFired) analyzeNow()
                    }
                    MotionEvent.ACTION_CANCEL -> ui.removeCallbacks(longPress)
                }
                return true
            }
        })
        wm.addView(root, rootLp)
    }

    /* ---------------- পপআপ ---------------- */

    private fun tv(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun pill(t: String, color: Int) = TextView(this).apply {
        text = t; textSize = 14f; setTextColor(color); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#F2101820")); cornerRadius = dp(22).toFloat(); setStroke(dp(2), color)
        }
    }

    private fun resultCard(r: SignalResult): View {
        val color = when (r.direction) {
            Direction.CALL -> Color.parseColor("#00E676")
            Direction.PUT -> Color.parseColor("#FF5252")
            Direction.WAIT -> Color.parseColor("#B0BEC5")
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2101820")); cornerRadius = dp(18).toFloat(); setStroke(dp(2), color)
            }
        }
        card.addView(tv(
            when (r.direction) { Direction.CALL -> "CALL ▲"; Direction.PUT -> "PUT ▼"; Direction.WAIT -> "WAIT" },
            22f, color, true
        ))
        card.addView(tv(
            if (r.direction == Direction.WAIT) "NO CLEAR SETUP" else "${r.confidence}%",
            if (r.direction == Direction.WAIT) 13f else 28f, color, true
        ))
        if (r.direction != Direction.WAIT) {
            card.addView(tv("Next ${tfLabels[tfIndex()]} candle • ${r.confirmations}/6 confirmations", 11f, Color.parseColor("#B0BEC5")))
        } else {
            card.addView(tv(r.note, 11f, Color.parseColor("#B0BEC5")))
        }
        card.addView(tv("Estimate only — not guaranteed", 10f, Color.parseColor("#78909C")))
        return card
    }

    private fun addPopup(v: View, autoRemoveMs: Long = 0L) {
        val lp = LinearLayout.LayoutParams(dp(280), LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(6) }
        popupBox.addView(v, lp)
        closeBtn.visibility = View.VISIBLE
        if (autoRemoveMs > 0) ui.postDelayed({ removePopup(v) }, autoRemoveMs)
    }

    private fun removePopup(v: View) {
        popupBox.removeView(v)
        if (v === analyzingPill) analyzingPill = null
        if (popupBox.childCount == 0) closeBtn.visibility = View.GONE
    }

    /** X চাপলে সবচেয়ে নতুন পপআপটা সরে যায়, এভাবে এক এক করে সব সরানো যায় */
    private fun removeLastPopup() {
        val n = popupBox.childCount
        if (n > 0) removePopup(popupBox.getChildAt(n - 1))
    }

    private fun clearPopups() {
        popupBox.removeAllViews()
        analyzingPill = null
        closeBtn.visibility = View.GONE
    }

    /* ---------------- স্ক্যান ও সিগন্যাল ---------------- */

    private fun analyzeNow() {
        if (busy) return
        busy = true
        ui.removeCallbacks(logoReset)
        val secs = analysisSec()
        val sensNow = prefs.getInt("sens", 1)
        val withEntry = prefs.getBoolean("auto_entry", false)

        clearPopups()
        if (!withEntry) {                      // অটো এন্ট্রি চালু থাকলে কোনো পপআপ নয়
            val pillView = pill("● ANALYZING MARKET", Color.parseColor("#2979FF"))
            analyzingPill = pillView
            addPopup(pillView)
        }
        logo.statusColor = Color.parseColor("#FFD54F")
        tickerStart = SystemClock.uptimeMillis()
        tickerTotal = secs * 1000L + 1200L
        ui.post(ticker)

        Thread {
            // ১) সব ওভারলে লুকিয়ে পরিষ্কার প্রথম ফ্রেম
            ui.post { root.visibility = View.INVISIBLE; scanView.visibility = View.GONE }
            val b1 = waitFreshFrame()
            if (b1 == null) { ui.post { marketNotVisible(withEntry) }; return@Thread }
            val (top, bottom) = ChartReader.autoRegion(b1)
            val c1 = ChartReader.detect(b1, top, bottom)
            if (c1.size < 12) { ui.post { marketNotVisible(withEntry) }; return@Thread }

            // ২) স্ক্রিন একটু অন্ধকার + নীল স্ক্যান লাইন
            ui.post { root.visibility = View.VISIBLE; scanView.begin(top, bottom) }
            Thread.sleep(secs * 1000L)

            // ৩) শেষ পরিষ্কার ফ্রেম
            ui.post { scanView.end(); root.visibility = View.INVISIBLE }
            val b2 = waitFreshFrame()
            val c2 = if (b2 != null) ChartReader.detect(b2, top, bottom) else emptyList()
            val finalCandles = if (c2.size >= 12) c2 else c1
            val delta = if (c2.size >= 12) c2.last().close - c1.last().close else 0.0
            val res = SignalEngine.analyze(finalCandles, top, bottom - top, delta, sensNow)
            ui.post {
                root.visibility = View.VISIBLE
                busy = false
                showResult(res, withEntry)
                if (withEntry && res.direction != Direction.WAIT) performAutoEntry(res)
            }
        }.start()
    }

    private fun marketNotVisible(withEntry: Boolean) {
        busy = false
        scanView.end()
        root.visibility = View.VISIBLE
        analyzingPill?.let { removePopup(it) }
        logo.status = "WAITING"; logo.statusColor = Color.parseColor("#00E676")
        if (!withEntry) addPopup(pill("✖ CAN'T SEE MARKET\nOpen the candle chart", Color.parseColor("#FF5252")), 8000)
    }

    @Suppress("DEPRECATION")
    private fun alertUser() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(350, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    private fun showResult(r: SignalResult, withEntry: Boolean) {
        if (r.direction != Direction.WAIT && r.direction != lastDir) alertUser()
        lastDir = r.direction
        val color = when (r.direction) {
            Direction.CALL -> Color.parseColor("#00E676")
            Direction.PUT -> Color.parseColor("#FF5252")
            Direction.WAIT -> Color.parseColor("#B0BEC5")
        }
        logo.status = when (r.direction) { Direction.CALL -> "CALL"; Direction.PUT -> "PUT"; Direction.WAIT -> "WAIT" }
        logo.statusColor = color
        analyzingPill?.let { removePopup(it) }
        if (!withEntry) addPopup(resultCard(r), 12000)
        ui.postDelayed(logoReset, 12000)
    }

    /* ---------------- অটো এন্ট্রি ---------------- */

    private fun buyPt(): Pair<Float, Float>? =
        if (prefs.contains("bx")) prefs.getFloat("bx", 0f) to prefs.getFloat("by", 0f) else null

    private fun sellPt(): Pair<Float, Float>? =
        if (prefs.contains("sx")) prefs.getFloat("sx", 0f) to prefs.getFloat("sy", 0f) else null

    /** পরপর দুটো ট্যাপ নিয়ে BUY ও SELL বাটনের জায়গা সেভ করে */
    private fun calibrate() {
        val tv = TextView(this).apply {
            text = "BUY বাটনের উপরে ট্যাপ করো"
            textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#AA000000"))
        }
        var step = 0
        tv.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                if (step == 0) {
                    prefs.edit().putFloat("bx", e.rawX).putFloat("by", e.rawY).apply()
                    step = 1
                    tv.text = "এবার SELL বাটনের উপরে ট্যাপ করো"
                } else {
                    prefs.edit().putFloat("sx", e.rawX).putFloat("sy", e.rawY).apply()
                    try { wm.removeView(tv) } catch (_: Exception) {}
                    toast("BUY ও SELL বাটনের জায়গা সেভ হয়েছে")
                }
            }
            true
        }
        wm.addView(
            tv,
            overlayParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                Gravity.TOP or Gravity.START
            )
        )
    }

    private fun performAutoEntry(r: SignalResult) {
        if (r.confidence < prefs.getInt("entry_min", 55)) return    // দুর্বল সিগন্যালে এন্ট্রি নয়
        val cap = prefs.getInt("entry_cap", 5)           // 0 = সীমাহীন
        if (cap > 0 && autoCount >= cap) {
            prefs.edit().putBoolean("auto_entry", false).apply()
            toast("AUTO ENTRY এর সীমা ($cap) শেষ — বন্ধ হয়েছে")
            return
        }
        val p = if (r.direction == Direction.CALL) buyPt() else sellPt()
        if (p == null) { toast("আগে CALIBRATE করো"); return }
        val svc = TapService.instance
        if (svc == null) { toast("ACCESSIBILITY চালু নেই"); return }
        if (svc.tap(p.first, p.second)) autoCount++
    }

    /* ---------------- স্ক্রিন রেকর্ড (অ্যাপের সুইচ বা S বাটন ধরে রাখলে) ---------------- */

    private var recPfd: ParcelFileDescriptor? = null

    private fun toggleRecord() {
        prefs.edit().putBoolean("record", !recording).apply()     // লিসেনার শুরু/বন্ধ করবে
    }

    private fun startRecord() {
        if (recording) return
        try {
            val name = "S_rec_${System.currentTimeMillis()}.mp4"
            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            rec.setVideoSize(sw, sh)
            rec.setVideoFrameRate(30)
            rec.setVideoEncodingBitRate(6_000_000)
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, name)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/SSignal")
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)
                    ?: throw IllegalStateException("সেভ করার জায়গা পাওয়া যায়নি")
                recPfd = contentResolver.openFileDescriptor(uri, "w")
                rec.setOutputFile(recPfd!!.fileDescriptor)
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
                rec.setOutputFile(File(dir, name).absolutePath)
            }
            rec.prepare()
            recDisplay = projection?.createVirtualDisplay(
                "S_rec", sw, sh, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.surface, null, null
            )
            rec.start()
            recorder = rec
            recording = true
            toast("স্ক্রিন রেকর্ড শুরু হয়েছে")
        } catch (e: Exception) {
            toast("রেকর্ড শুরু করা যায়নি: ${e.message}")
            releaseRecorder()
            prefs.edit().putBoolean("record", false).apply()
        }
    }

    private fun stopRecord() {
        if (!recording) return
        releaseRecorder()
        toast("রেকর্ডিং সেভ হয়েছে — গ্যালারি → Movies/SSignal")
    }

    private fun releaseRecorder() {
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recDisplay?.release()
        try { recPfd?.close() } catch (_: Exception) {}
        recPfd = null; recorder = null; recDisplay = null; recording = false
    }

    /* ---------------- ক্লিনআপ ---------------- */

    override fun onDestroy() {
        busy = false
        ui.removeCallbacksAndMessages(null)
        try { prefs.unregisterOnSharedPreferenceChangeListener(prefListener) } catch (_: Exception) {}
        prefs.edit().putBoolean("auto_signal", false).putBoolean("auto_entry", false).putBoolean("record", false).apply()
        releaseRecorder()
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        captureDisplay?.release()
        reader?.close()
        projection?.stop()
        if (::wm.isInitialized) {
            if (::root.isInitialized) try { wm.removeView(root) } catch (_: Exception) {}
            if (::scanView.isInitialized) try { wm.removeView(scanView) } catch (_: Exception) {}
        }
        super.onDestroy()
    }
}
