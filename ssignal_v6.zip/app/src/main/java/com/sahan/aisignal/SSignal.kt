/*
 * S SIGNAL  -  Floating chart-analysis overlay (single file, Kotlin, no external libraries)
 *
 * কী করে:
 *  1) ফ্লোটিং "S" লোগো স্ক্রিনের উপর ভাসে (ড্র্যাগ করা যায়, ট্যাপ করলে প্যানেল খোলে)
 *  2) MediaProjection দিয়ে স্ক্রিন ক্যাপচার করে চার্টের ক্যান্ডেল (সবুজ/লাল) পড়ে
 *  3) RSI (Wilder) + MACD + EMA ট্রেন্ড + ক্যান্ডেল মোমেন্টাম + সাপোর্ট/রেজিস্ট্যান্স মিলিয়ে
 *     মাল্টিপল কনফার্মেশনে CALL / PUT / WAIT সিগন্যাল দেয়
 *  4) চার্টের উপর নীল (BLUE) দাগ টানে: সাপোর্ট, রেজিস্ট্যান্স, শেষ প্রাইস
 *  5) স্ক্রিন রেকর্ড (MP4) করা যায়
 *
 * গুরুত্বপূর্ণ: এটা একটি সম্ভাবনা-নির্ভর টেকনিক্যাল বিশ্লেষণ টুল। কোনো সিগন্যালই নিশ্চিত নয়।
 * Binary/OTC ট্রেডিংয়ে পুরো টাকা হারানোর ঝুঁকি আছে।
 *
 * ---------------------------------------------------------------------------
 * SETUP (Android Studio):
 *  - New Project > Empty Views Activity (Kotlin), package: com.sahan.aisignal
 *  - minSdk 26, compileSdk/targetSdk 34
 *  - এই ফাইলটা app/src/main/java/com/sahan/aisignal/SSignal.kt এ রাখো
 *    (MainActivity.kt ফাইলটা মুছে দাও)
 *  - AndroidManifest.xml এ নিচেরটা বসাও:
 *
 *  <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
 *  <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
 *  <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION"/>
 *  <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
 *
 *  <application android:label="S Signal" android:icon="@mipmap/ic_launcher"
 *               android:theme="@android:style/Theme.DeviceDefault.NoActionBar">
 *      <activity android:name=".MainActivity" android:exported="true">
 *          <intent-filter>
 *              <action android:name="android.intent.action.MAIN"/>
 *              <category android:name="android.intent.category.LAUNCHER"/>
 *          </intent-filter>
 *      </activity>
 *      <service android:name=".OverlayService" android:exported="false"
 *               android:foregroundServiceType="mediaProjection"/>
 *  </application>
 * ---------------------------------------------------------------------------
 */
package com.sahan.aisignal

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.animation.ValueAnimator
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/* =============================================================================
 *  DATA MODELS
 * ========================================================================== */

data class Candle(
    val open: Double, val high: Double, val low: Double, val close: Double, val x: Float
) {
    val bullish get() = close > open
}

enum class Direction { CALL, PUT, WAIT }

data class SignalResult(
    val direction: Direction,
    val confidence: Int,          // আনুমানিক সম্ভাবনা % (সর্বোচ্চ ~71, নিশ্চয়তা নয়)
    val score: Int,               // -9 .. +9
    val confirmations: Int,       // কয়টা ইন্ডিকেটর একই দিকে
    val rsi: Double,
    val macdHist: Double,
    val trend: String,
    val candleCount: Int,
    val note: String,
    val supportY: Float? = null,
    val resistanceY: Float? = null,
    val lastY: Float? = null
)

/* =============================================================================
 *  INDICATORS  (RSI, EMA, MACD)
 * ========================================================================== */

object Indicators {

    /** Exponential Moving Average */
    fun ema(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val k = 2.0 / (period + 1)
        val out = ArrayList<Double>(values.size)
        var prev = values[0]
        out.add(prev)
        for (i in 1 until values.size) {
            prev = values[i] * k + prev * (1 - k)
            out.add(prev)
        }
        return out
    }

    /** RSI - Wilder's smoothing. রিটার্ন লিস্টের দৈর্ঘ্য = closes.size - period */
    fun rsi(closes: List<Double>, period: Int = 14): List<Double> {
        if (closes.size <= period) return emptyList()
        var gain = 0.0
        var loss = 0.0
        for (i in 1..period) {
            val d = closes[i] - closes[i - 1]
            if (d >= 0) gain += d else loss -= d
        }
        var avgGain = gain / period
        var avgLoss = loss / period
        val out = ArrayList<Double>()
        fun value(): Double =
            if (avgLoss == 0.0) 100.0 else 100.0 - 100.0 / (1.0 + avgGain / avgLoss)
        out.add(value())
        for (i in period + 1 until closes.size) {
            val d = closes[i] - closes[i - 1]
            val g = max(d, 0.0)
            val l = max(-d, 0.0)
            avgGain = (avgGain * (period - 1) + g) / period
            avgLoss = (avgLoss * (period - 1) + l) / period
            out.add(value())
        }
        return out
    }

    data class Macd(val line: List<Double>, val signal: List<Double>, val hist: List<Double>)

    /** MACD = EMA(fast) - EMA(slow);  Signal = EMA(MACD, signalPeriod);  Hist = MACD - Signal */
    fun macd(closes: List<Double>, fast: Int = 12, slow: Int = 26, signalP: Int = 9): Macd {
        val ef = ema(closes, fast)
        val es = ema(closes, slow)
        val line = closes.indices.map { ef[it] - es[it] }
        val sig = ema(line, signalP)
        val hist = line.indices.map { line[it] - sig[it] }
        return Macd(line, sig, hist)
    }
}

/* =============================================================================
 *  CHART READER  (স্ক্রিনশট থেকে সবুজ/লাল ক্যান্ডেল বের করা)
 * ========================================================================== */

object ChartReader {

    private const val MIN_PIXELS = 6      // একটা কলামে কমপক্ষে এতগুলো রঙিন পিক্সেল
    private const val MIN_WIDTH = 3       // ক্যান্ডেলের ন্যূনতম প্রস্থ (পিক্সেল)

    private fun isGreen(r: Int, g: Int, b: Int) = g > 140 && g > r + 60 && g > b + 60
    private fun isRed(r: Int, g: Int, b: Int) = r > 170 && r > g + 80 && r > b + 70

    /**
     * bmp এর [regionTop, regionBottom) এলাকায় ক্যান্ডেল খোঁজে।
     * প্রাইস = (এলাকার উচ্চতা - y), অর্থাৎ উপরে গেলে প্রাইস বাড়ে (আপেক্ষিক স্কেল)।
     */
    fun detect(bmp: Bitmap, regionTop: Int, regionBottom: Int): List<Candle> {
        val w = bmp.width
        val h = regionBottom - regionTop
        if (h <= 10) return emptyList()
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, regionTop, w, h)

        val type = IntArray(w)                   // 0 = কিছু নেই, 1 = সবুজ, 2 = লাল
        val colMin = IntArray(w) { Int.MAX_VALUE }
        val colMax = IntArray(w) { -1 }

        for (x in 0 until w) {
            var gc = 0; var gMin = Int.MAX_VALUE; var gMax = -1
            var rc = 0; var rMin = Int.MAX_VALUE; var rMax = -1
            for (y in 0 until h) {
                val p = px[y * w + x]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                if (isGreen(r, g, b)) {
                    gc++; if (y < gMin) gMin = y; if (y > gMax) gMax = y
                } else if (isRed(r, g, b)) {
                    rc++; if (y < rMin) rMin = y; if (y > rMax) rMax = y
                }
            }
            if (gc >= MIN_PIXELS && gc >= rc) {
                type[x] = 1; colMin[x] = gMin; colMax[x] = gMax
            } else if (rc >= MIN_PIXELS) {
                type[x] = 2; colMin[x] = rMin; colMax[x] = rMax
            }
        }

        val candles = ArrayList<Candle>()
        var x = 0
        while (x < w) {
            if (type[x] == 0) { x++; continue }
            val t = type[x]
            var end = x
            while (end + 1 < w && type[end + 1] == t) end++
            val width = end - x + 1
            if (width >= MIN_WIDTH) {
                val mins = ArrayList<Int>()
                val maxs = ArrayList<Int>()
                var hi = Int.MAX_VALUE
                var lo = -1
                for (cx in x..end) {
                    mins.add(colMin[cx]); maxs.add(colMax[cx])
                    if (colMin[cx] < hi) hi = colMin[cx]
                    if (colMax[cx] > lo) lo = colMax[cx]
                }
                mins.sort(); maxs.sort()
                val bodyTop = mins[mins.size / 2]       // median => উইক বাদ পড়ে, বডি থাকে
                val bodyBottom = maxs[maxs.size / 2]
                fun price(y: Int) = (h - y).toDouble()
                val open: Double
                val close: Double
                if (t == 1) { open = price(bodyBottom); close = price(bodyTop) }
                else        { open = price(bodyTop);    close = price(bodyBottom) }
                candles.add(Candle(open, price(hi), price(lo), close, (x + end) / 2f))
            }
            x = end + 1
        }
        return candles
    }
}

/* =============================================================================
 *  SIGNAL ENGINE  (মাল্টিপল কনফার্মেশন)
 * ========================================================================== */

object SignalEngine {

    fun analyze(candles: List<Candle>, regionTop: Int, regionH: Int, liveDelta: Double = 0.0): SignalResult {
        val n = candles.size
        if (n < 12) {
            return SignalResult(
                Direction.WAIT, 0, 0, 0, 0.0, 0.0, "-", n,
                "মাত্র $n টা ক্যান্ডেল পাওয়া গেছে (কমপক্ষে ১২ লাগবে). চার্ট এলাকা ঠিক করো বা জুম আউট করো।"
            )
        }

        val closes = candles.map { it.close }
        // ক্যান্ডেল কম হলে দ্রুত (adaptive) পিরিয়ড
        val quick = n < 35
        val rsiP = if (quick) 7 else 14
        val emaF = if (quick) 5 else 9
        val emaS = if (quick) 13 else 21
        val mF = if (quick) 5 else 12
        val mS = if (quick) 13 else 26
        val mG = if (quick) 4 else 9

        val rsiList = Indicators.rsi(closes, rsiP)
        val macd = Indicators.macd(closes, mF, mS, mG)
        val eF = Indicators.ema(closes, emaF)
        val eS = Indicators.ema(closes, emaS)

        val rsi = rsiList.last()
        val rsiPrev = if (rsiList.size > 1) rsiList[rsiList.size - 2] else rsi
        val hist = macd.hist.last()
        val histPrev = macd.hist[macd.hist.size - 2]

        // ---- ১) RSI ভোট ----
        val rsiVote = when {
            rsi < 30 -> +2
            rsi < 45 && rsi > rsiPrev -> +1
            rsi > 70 -> -2
            rsi > 55 && rsi < rsiPrev -> -1
            else -> 0
        }

        // ---- ২) MACD ভোট ----
        val macdVote = when {
            histPrev <= 0 && hist > 0 -> +2          // বুলিশ ক্রস
            histPrev >= 0 && hist < 0 -> -2          // বেয়ারিশ ক্রস
            hist > 0 && hist > histPrev -> +1
            hist < 0 && hist < histPrev -> -1
            else -> 0
        }

        // ---- ৩) EMA ট্রেন্ড ভোট ----
        val hi = candles.maxOf { it.high }
        val lo = candles.minOf { it.low }
        val range = max(hi - lo, 1.0)
        val gap = eF.last() - eS.last()
        val emaVote = when {
            abs(gap) < range * 0.01 -> 0              // সাইডওয়েজ
            gap > 0 -> +1
            else -> -1
        }
        val trend = when (emaVote) { 1 -> "UP"; -1 -> "DOWN"; else -> "SIDEWAYS" }

        // ---- ৪) ক্যান্ডেল মোমেন্টাম (শেষ ৩ ক্যান্ডেল) ----
        val last3 = candles.takeLast(3)
        val candleVote = when {
            last3.all { it.bullish } -> +1
            last3.none { it.bullish } -> -1
            else -> 0
        }

        // ---- ৫) সাপোর্ট / রেজিস্ট্যান্স ----
        val last = closes.last()
        val srVote = when {
            last <= lo + range * 0.08 -> +1           // সাপোর্টের কাছে
            last >= hi - range * 0.08 -> -1           // রেজিস্ট্যান্সের কাছে
            else -> 0
        }

        // ---- ৬) লাইভ মোমেন্টাম (বিশ্লেষণের ৩-৫ সেকেন্ডে চলমান ক্যান্ডেলের দিক) ----
        val momVote = when {
            liveDelta > range * 0.02 -> +1
            liveDelta < -range * 0.02 -> -1
            else -> 0
        }

        val votes = listOf(rsiVote, macdVote, emaVote, candleVote, srVote, momVote)
        val score = votes.sum()
        val sign = if (score > 0) 1 else if (score < 0) -1 else 0
        val confirms = if (sign == 0) 0 else votes.count { it * sign > 0 }

        val dir = when {
            score >= 3 && confirms >= 3 -> Direction.CALL
            score <= -3 && confirms >= 3 -> Direction.PUT
            else -> Direction.WAIT
        }
        val confidence = if (dir == Direction.WAIT) 50 else 50 + min(abs(score), 7) * 3

        fun toScreenY(price: Double) = regionTop + (regionH - price).toFloat()

        val note = when (dir) {
            Direction.CALL -> "$confirms/6 ইন্ডিকেটর বুলিশ."
            Direction.PUT -> "$confirms/6 ইন্ডিকেটর বেয়ারিশ."
            Direction.WAIT -> "পর্যাপ্ত কনফার্মেশন নেই — অপেক্ষা করো."
        } + if (quick) " (দ্রুত মোড: ক্যান্ডেল কম)" else ""

        return SignalResult(
            dir, confidence, score, confirms, rsi, hist, trend, n, note,
            supportY = toScreenY(lo), resistanceY = toScreenY(hi), lastY = toScreenY(last)
        )
    }
}

/* =============================================================================
 *  VIEWS  (S লোগো + নীল দাগের ওভারলে)
 * ========================================================================== */

private fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

class LogoView(ctx: Context) : View(ctx) {
    var status = "WAITING"
        set(value) { field = value; invalidate() }
    var statusColor = Color.parseColor("#00E676")
        set(value) { field = value; invalidate() }

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2061A1C") }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00F5D4"); style = Paint.Style.STROKE; strokeWidth = ctx.dp(3).toFloat()
    }
    private val letter = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B9FFE6"); textSize = ctx.dp(38).toFloat(); typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = ctx.dp(9).toFloat(); typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val tagBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2050E10") }
    private val tagStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E676"); style = Paint.Style.STROKE; strokeWidth = ctx.dp(1).toFloat()
    }
    private val tagText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E676"); textSize = ctx.dp(9).toFloat(); typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(c: Canvas) {
        val d = ctx().dp(1).toFloat()
        val side = width - 12f
        val badge = RectF(6f, 6f, 6f + side, 6f + side)
        c.drawRoundRect(badge, 16 * d, 16 * d, bg)
        c.drawRoundRect(badge, 16 * d, 16 * d, stroke)
        c.drawText("S", width / 2f, badge.top + side * 0.60f, letter)
        small.color = statusColor
        c.drawText(status, width / 2f, badge.bottom - 9 * d, small)

        val tag = RectF(4f, badge.bottom + 8 * d, width - 4f, badge.bottom + 28 * d)
        c.drawRoundRect(tag, 3 * d, 3 * d, tagBg)
        c.drawRoundRect(tag, 3 * d, 3 * d, tagStroke)
        c.drawText("S SIGNAL", width / 2f, tag.centerY() + 3.5f * d, tagText)
    }

    private fun ctx() = context
}

/** বিশ্লেষণের সময় চার্টের উপর দিয়ে ওঠানামা করা নীল স্ক্যান লাইন */
class ScanView(ctx: Context) : View(ctx) {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2979FF"); strokeWidth = ctx.dp(3).toFloat()
    }
    private val glow = Paint()
    private var top = 0
    private var bottom = 0
    private var pos = 0f
    private var anim: ValueAnimator? = null

    fun begin(t: Int, b: Int) {
        top = t; bottom = b
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            addUpdateListener { pos = it.animatedValue as Float; invalidate() }
            start()
        }
        visibility = VISIBLE
    }

    fun end() {
        anim?.cancel(); anim = null
        visibility = GONE
    }

    override fun onDraw(c: Canvas) {
        val y = top + (bottom - top) * pos
        val h = context.dp(46).toFloat()
        glow.shader = LinearGradient(
            0f, y - h, 0f, y + h,
            intArrayOf(0x002979FF, 0x662979FF, 0x002979FF),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, y - h, width.toFloat(), y + h, glow)
        c.drawLine(0f, y, width.toFloat(), y, line)
    }
}

class LineOverlayView(ctx: Context) : View(ctx) {
    private val blue = Color.parseColor("#2979FF")
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = blue; strokeWidth = ctx.dp(3).toFloat(); style = Paint.Style.STROKE
    }
    private val dashed = Paint(line).apply {
        pathEffect = DashPathEffect(floatArrayOf(24f, 16f), 0f); strokeWidth = ctx.dp(2).toFloat()
    }
    private val region = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#552979FF"); strokeWidth = 2f; style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(8f, 12f), 0f)
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = blue; textSize = ctx.dp(11).toFloat(); typeface = Typeface.DEFAULT_BOLD
    }

    var result: SignalResult? = null
        set(value) { field = value; invalidate() }
    var regionTop = 0
    var regionBottom = 0
    var showRegion = false

    fun setRegion(top: Int, bottom: Int, show: Boolean) {
        regionTop = top; regionBottom = bottom; showRegion = show; invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        if (showRegion) {
            c.drawLine(0f, regionTop.toFloat(), w, regionTop.toFloat(), region)
            c.drawLine(0f, regionBottom.toFloat(), w, regionBottom.toFloat(), region)
        }
        val r = result ?: return
        r.resistanceY?.let { c.drawLine(0f, it, w, it, line); c.drawText("RESISTANCE", 12f, it - 8f, label) }
        r.supportY?.let { c.drawLine(0f, it, w, it, line); c.drawText("SUPPORT", 12f, it - 8f, label) }
        r.lastY?.let { c.drawLine(0f, it, w, it, dashed); c.drawText("PRICE", w - ctx().dp(70), it - 8f, label) }

        // মাঝখানের ফলাফল বক্স
        val accent = when (r.direction) {
            Direction.CALL -> Color.parseColor("#00E676")
            Direction.PUT -> Color.parseColor("#FF5252")
            Direction.WAIT -> Color.parseColor("#B0BEC5")
        }
        boxStroke.color = accent
        bigText.color = accent
        subText.color = accent
        val d = ctx().dp(1).toFloat()
        val box = RectF(w * 0.12f, height * 0.40f, w * 0.88f, height * 0.40f + 84 * d)
        c.drawRoundRect(box, 12 * d, 12 * d, boxFill)
        c.drawRoundRect(box, 12 * d, 12 * d, boxStroke)
        val big = if (r.direction == Direction.WAIT) "WAIT" else "${r.confidence}%"
        c.drawText(big, box.centerX(), box.top + 44 * d, bigText)
        val sub = when (r.direction) {
            Direction.CALL -> "CALL ▲  •  ESTIMATED PROBABILITY"
            Direction.PUT -> "PUT ▼  •  ESTIMATED PROBABILITY"
            Direction.WAIT -> "NO CLEAR SETUP"
        }
        c.drawText(sub, box.centerX(), box.top + 68 * d, subText)
    }

    private val boxFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#B3061014") }
    private val boxStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dp(2).toFloat()
    }
    private val bigText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = ctx.dp(34).toFloat(); typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val subText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = ctx.dp(11).toFloat(); typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }

    private fun ctx() = context
}

/* =============================================================================
 *  MAIN ACTIVITY  (পারমিশন নেয় ও সার্ভিস চালু করে)
 * ========================================================================== */

class MainActivity : Activity() {

    private val REQ_OVERLAY = 101
    private val REQ_CAPTURE = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.parseColor("#0B1220"))
        }
        root.addView(TextView(this).apply {
            text = "S"; textSize = 72f; setTextColor(Color.parseColor("#00E5FF"))
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "S SIGNAL\nRSI • MACD • EMA চার্ট অ্যানালাইজার"
            textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(28))
        })
        root.addView(Button(this).apply {
            text = "START"
            setOnClickListener { start() }
        })
        root.addView(TextView(this).apply {
            text = "\nসিগন্যাল শুধু সম্ভাবনা, নিশ্চয়তা নয়। ট্রেডিংয়ে সম্পূর্ণ মূলধন হারানোর ঝুঁকি আছে।"
            textSize = 12f; setTextColor(Color.parseColor("#90A4AE")); gravity = Gravity.CENTER
        })
        setContentView(root)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "অন্য অ্যাপের উপর দেখানোর পারমিশন দাও", Toast.LENGTH_LONG).show()
            startActivityForResult(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")),
                REQ_OVERLAY
            )
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)   // স্ক্রিন ক্যাপচার পারমিশন
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_OVERLAY -> if (Settings.canDrawOverlays(this)) start()
            REQ_CAPTURE -> if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, OverlayService::class.java)
                    .putExtra(OverlayService.EXTRA_CODE, resultCode)
                    .putExtra(OverlayService.EXTRA_DATA, data)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                moveTaskToBack(true)       // অ্যাপ মিনিমাইজ — এবার ট্রেডিং অ্যাপ খোলো
            } else {
                Toast.makeText(this, "স্ক্রিন ক্যাপচার পারমিশন লাগবে", Toast.LENGTH_LONG).show()
            }
        }
    }
}

/* =============================================================================
 *  TAP SERVICE  (Accessibility - অটো এন্ট্রির জন্য স্ক্রিনে ট্যাপ করে)
 * ========================================================================== */

class TapService : AccessibilityService() {
    companion object {
        @Volatile var instance: TapService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesture, null, null)
    }
}

/* =============================================================================
 *  OVERLAY SERVICE  (মূল কাজ এখানে)
 * ========================================================================== */

class OverlayService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "s_signal_channel"
        private const val MAX_AUTO_ENTRIES = 5       // প্রতিবার AUTO ENTRY চালুর পর সর্বোচ্চ এন্ট্রি
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private val prefs by lazy { getSharedPreferences("s_signal", Context.MODE_PRIVATE) }

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var captureDisplay: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var recDisplay: VirtualDisplay? = null
    private var recording = false

    private var sw = 0
    private var sh = 0
    private var dpi = 0

    private lateinit var logo: LogoView
    private lateinit var lines: LineOverlayView
    private lateinit var scanView: ScanView
    private lateinit var panel: LinearLayout
    private lateinit var resultText: TextView
    private lateinit var detailText: TextView
    private lateinit var autoSigBtn: Button
    private lateinit var autoEntryBtn: Button
    private lateinit var recBtn: Button
    private val tfButtons = ArrayList<Button>()

    // টাইমফ্রেম: যে ক্যান্ডেলের জন্য সিগন্যাল চাও
    private val tfLabels = listOf("5s", "10s", "15s", "30s", "1m")
    private val tfSecs = listOf(5, 10, 15, 30, 60)
    private var tfIndex = 1

    private var panelOpen = false
    private var autoSignal = false
    private var autoEntry = false
    private var autoCount = 0
    private var busy = false
    private var topPct = 12
    private var bottomPct = 68
    private var lastDir = Direction.WAIT

    // সবচেয়ে সাম্প্রতিক স্ক্রিন ফ্রেম (প্রতি ~০.৫ সেকেন্ডে আপডেট হয়)
    @Volatile private var lastBmp: Bitmap? = null
    @Volatile private var lastBmpAt = 0L
    private var lastConvertAt = 0L

    private fun tfSec() = tfSecs[tfIndex]
    private fun analysisSec() = if (tfSec() <= 10) 3 else 4      // ৩-৪ সেকেন্ড বিশ্লেষণ
    private fun cycleMs() = max(tfSec(), analysisSec() + 2) * 1000L

    private val autoLoop = object : Runnable {
        override fun run() {
            if (autoSignal) {
                if (!busy) analyzeNow()
                ui.postDelayed(this, cycleMs())
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        val code = intent?.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        if (projection == null) {
            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            setupScreenMetrics()
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mpm.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { ui.post { stopSelf() } }
            }, ui)
            setupCapture()
            buildOverlay()
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "S Signal", NotificationManager.IMPORTANCE_LOW))
        }
        val n = (if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this))
            .setContentTitle("S Signal চলছে")
            .setContentText("চার্ট অ্যানালাইজার সক্রিয়")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    @Suppress("DEPRECATION")
    private fun setupScreenMetrics() {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        sw = m.widthPixels; sh = m.heightPixels; dpi = m.densityDpi
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    /* ---------------- স্ক্রিন ক্যাপচার ---------------- */

    private fun setupCapture() {
        val r = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        reader = r
        captureDisplay = projection?.createVirtualDisplay(
            "S_capture", sw, sh, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = SystemClock.uptimeMillis()
                if (now - lastConvertAt >= 450) {
                    lastConvertAt = now
                    val plane = img.planes[0]
                    val rowPad = plane.rowStride - plane.pixelStride * sw
                    val full = Bitmap.createBitmap(sw + rowPad / plane.pixelStride, sh, Bitmap.Config.ARGB_8888)
                    full.copyPixelsFromBuffer(plane.buffer)
                    val bmp = if (rowPad == 0) full else Bitmap.createBitmap(full, 0, 0, sw, sh)
                    lastBmp = bmp
                    lastBmpAt = SystemClock.uptimeMillis()
                }
            } catch (_: Exception) {
            } finally {
                img.close()
            }
        }, ui)
    }

    /* ---------------- ওভারলে UI ---------------- */

    private fun overlayParams(w: Int, h: Int, flags: Int, gravity: Int, x: Int = 0, y: Int = 0) =
        WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).also { it.gravity = gravity; it.x = x; it.y = y }

    private val passThroughFlags =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    private fun buildOverlay() {
        // ১) নীল দাগের লেয়ার (টাচ ধরে না)
        lines = LineOverlayView(this)
        wm.addView(
            lines,
            overlayParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                passThroughFlags, Gravity.TOP or Gravity.START
            )
        )
        updateRegion(false)

        // স্ক্যান লাইন (টাচ ধরে না)
        scanView = ScanView(this)
        scanView.visibility = View.GONE
        wm.addView(
            scanView,
            overlayParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                passThroughFlags, Gravity.TOP or Gravity.START
            )
        )

        // ২) প্যানেল
        panel = buildPanel()
        panel.visibility = View.GONE
        wm.addView(
            panel,
            overlayParams(
                WindowManager.LayoutParams.MATCH_PARENT, (sh * 0.58f).toInt(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                Gravity.BOTTOM
            )
        )

        // ৩) S লোগো (ড্র্যাগযোগ্য) - Buy/Sell বাটনের উপরে রেখো না
        logo = LogoView(this)
        val lp = overlayParams(
            dp(84), dp(112),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            Gravity.TOP or Gravity.START, dp(12), dp(160)
        )
        logo.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > 10 || abs(dy) > 10) moved = true
                        lp.x = sx + dx; lp.y = sy + dy
                        wm.updateViewLayout(logo, lp)
                    }
                    MotionEvent.ACTION_UP -> if (!moved) togglePanel()
                }
                return true
            }
        })
        wm.addView(logo, lp)
    }

    private fun buildPanel(): LinearLayout {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2101B2D"))
                cornerRadii = floatArrayOf(40f, 40f, 40f, 40f, 0f, 0f, 0f, 0f)
                setStroke(dp(2), Color.parseColor("#00E5FF"))
            }
        }
        val sv = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sv.addView(box)
        outer.addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT))

        box.addView(TextView(this).apply {
            text = "S SIGNAL  •  RSI + MACD + EMA"
            setTextColor(Color.parseColor("#00E5FF")); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
        })
        resultText = TextView(this).apply {
            text = "WAITING"; textSize = 28f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; setPadding(0, dp(2), 0, 0)
        }
        box.addView(resultText)
        detailText = TextView(this).apply {
            text = "ক্যান্ডেল শেষ হওয়ার ৫-৬ সেকেন্ড আগে ANALYZE চাপো"
            textSize = 12f; setTextColor(Color.parseColor("#B0BEC5")); setPadding(0, dp(2), 0, dp(8))
        }
        box.addView(detailText)

        // টাইমফ্রেম নির্বাচন
        box.addView(label("সিগন্যাল কোন টাইমের ক্যান্ডেলের জন্য (প্ল্যাটফর্মেও একই টাইম দাও)"))
        val tfRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tfLabels.forEachIndexed { i, t ->
            val b = smallButton(t) { tfIndex = i; refreshTf() }
            tfButtons.add(b)
            tfRow.addView(b, LinearLayout.LayoutParams(0, dp(42), 1f))
        }
        box.addView(tfRow)
        refreshTf()

        // ANALYZE | AUTO SIGNAL | REC
        autoSigBtn = smallButton("AUTO SIGNAL: OFF") { toggleAutoSignal() }
        recBtn = smallButton("● REC") { toggleRecord() }
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r1.addView(smallButton("ANALYZE") { analyzeNow() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        r1.addView(autoSigBtn, LinearLayout.LayoutParams(0, dp(46), 1f))
        r1.addView(recBtn, LinearLayout.LayoutParams(0, dp(46), 1f))
        box.addView(r1)

        // AUTO ENTRY | CALIBRATE | ACCESSIBILITY
        autoEntryBtn = smallButton("AUTO ENTRY: OFF") { toggleAutoEntry() }
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        r2.addView(autoEntryBtn, LinearLayout.LayoutParams(0, dp(46), 1f))
        r2.addView(smallButton("CALIBRATE") { calibrate() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        r2.addView(smallButton("ACCESSIBILITY") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }, LinearLayout.LayoutParams(0, dp(46), 1f))
        box.addView(r2)

        box.addView(TextView(this).apply {
            text = "AUTO ENTRY চালুর আগে: ১) ACCESSIBILITY এ S Signal অন করো  ২) CALIBRATE করে BUY ও SELL বাটন চিনিয়ে দাও।\n" +
                    "প্রতিবার সর্বোচ্চ $MAX_AUTO_ENTRIES টা এন্ট্রি, তারপর নিজে বন্ধ হয়।"
            textSize = 10f; setTextColor(Color.parseColor("#90A4AE")); setPadding(0, dp(6), 0, 0)
        })

        // চার্ট এলাকা
        box.addView(label("চার্ট উপরের সীমা"))
        box.addView(seek(0, 50, topPct) { topPct = it; updateRegion(true) })
        box.addView(label("চার্ট নিচের সীমা"))
        box.addView(seek(40, 100, bottomPct) { bottomPct = it; updateRegion(true) })

        box.addView(TextView(this).apply {
            text = "⚠ এটা সম্ভাবনা-ভিত্তিক বিশ্লেষণ, নিশ্চিত সিগন্যাল নয়। ঝুঁকি নিজের।"
            textSize = 10f; setTextColor(Color.parseColor("#78909C")); setPadding(0, dp(8), 0, dp(4))
        })
        box.addView(smallButton("STOP / EXIT") { stopSelf() }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(46)))
        return outer
    }

    private fun smallButton(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; textSize = 11f; isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 11f; setTextColor(Color.parseColor("#90A4AE")); setPadding(0, dp(6), 0, 0)
    }

    private fun seek(min: Int, max: Int, start: Int, onChange: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max - min; progress = start - min
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) onChange(p + min) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { ui.postDelayed({ lines.showRegion = false; lines.invalidate() }, 1200) }
        })
    }

    private fun refreshTf() {
        tfButtons.forEachIndexed { i, b -> b.text = if (i == tfIndex) "✔ ${tfLabels[i]}" else tfLabels[i] }
    }

    private fun refreshAutoEntryBtn() {
        autoEntryBtn.text = if (autoEntry) "AUTO ENTRY: ON ($autoCount/$MAX_AUTO_ENTRIES)" else "AUTO ENTRY: OFF"
    }

    private fun updateRegion(show: Boolean) {
        lines.setRegion(sh * topPct / 100, sh * bottomPct / 100, show)
    }

    private fun togglePanel() {
        panelOpen = !panelOpen
        panel.visibility = if (panelOpen) View.VISIBLE else View.GONE
    }

    private fun toggleAutoSignal() {
        autoSignal = !autoSignal
        autoSigBtn.text = if (autoSignal) "AUTO SIGNAL: ON" else "AUTO SIGNAL: OFF"
        ui.removeCallbacks(autoLoop)
        if (autoSignal) ui.post(autoLoop)      // এখন থেকে প্রতি টাইমফ্রেমে একবার বিশ্লেষণ
    }

    /* ---------------- বিশ্লেষণ (৩-৪ সেকেন্ড বাজার দেখে সিগন্যাল) ---------------- */

    private fun analyzeNow() {
        if (busy) return
        busy = true
        val secs = analysisSec()
        logo.statusColor = Color.parseColor("#FFD54F")
        logo.status = "SCAN ${secs}s"

        // নিজের দাগ/প্যানেল লুকিয়ে ফ্রেম পড়া
        lines.visibility = View.INVISIBLE
        panel.visibility = View.INVISIBLE
        val top = sh * topPct / 100
        val bottom = sh * bottomPct / 100
        scanView.begin(top, bottom)
        val startedAt = SystemClock.uptimeMillis()
        val withEntry = autoEntry

        Thread {
            var finalCandles: List<Candle> = emptyList()
            var firstClose: Double? = null
            var lastClose: Double? = null
            var seen: Bitmap? = null

            while (SystemClock.uptimeMillis() - startedAt < secs * 1000L) {
                Thread.sleep(500)
                val left = ((secs * 1000L - (SystemClock.uptimeMillis() - startedAt) + 999) / 1000).toInt()
                ui.post { if (busy) logo.status = "SCAN ${max(left, 0)}s" }
                val b = lastBmp
                if (b != null && b !== seen && lastBmpAt >= startedAt + 300) {
                    seen = b
                    val c = ChartReader.detect(b, top, bottom)
                    if (c.size >= 12) {
                        finalCandles = c
                        val cl = c.last().close
                        if (firstClose == null) firstClose = cl
                        lastClose = cl
                    }
                }
            }

            if (finalCandles.isEmpty()) {
                val b = lastBmp
                if (b == null) { ui.post { noFrame() }; return@Thread }
                finalCandles = ChartReader.detect(b, top, bottom)
            }
            val f = firstClose
            val l = lastClose
            val delta = if (f != null && l != null) l - f else 0.0
            val res = SignalEngine.analyze(finalCandles, top, bottom - top, delta)
            ui.post {
                restoreOverlay()
                showResult(res)
                busy = false
                if (withEntry && res.direction != Direction.WAIT) performAutoEntry(res)
            }
        }.start()
    }

    private fun noFrame() {
        restoreOverlay()
        logo.status = "NO FRAME"; logo.statusColor = Color.parseColor("#FF8A65")
        detailText.text = "স্ক্রিন ফ্রেম পাওয়া যায়নি — অ্যাপ বন্ধ করে START থেকে আবার চালু করো।"
        busy = false
    }

    private fun restoreOverlay() {
        scanView.end()
        lines.visibility = View.VISIBLE
        panel.visibility = if (panelOpen) View.VISIBLE else View.GONE
    }

    @Suppress("DEPRECATION")
    private fun alertUser() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(350, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    private fun showResult(r: SignalResult) {
        if (r.direction != Direction.WAIT && r.direction != lastDir) alertUser()
        lastDir = r.direction
        lines.result = if (r.direction == Direction.WAIT && r.candleCount < 12) null else r
        val (name, color) = when (r.direction) {
            Direction.CALL -> "CALL ▲" to Color.parseColor("#00E676")
            Direction.PUT -> "PUT ▼" to Color.parseColor("#FF5252")
            Direction.WAIT -> "WAIT" to Color.parseColor("#B0BEC5")
        }
        logo.status = name.substringBefore(' '); logo.statusColor = color
        resultText.text = if (r.direction == Direction.WAIT) name else "$name  ~${r.confidence}%"
        resultText.setTextColor(color)
        detailText.text = buildString {
            if (r.direction != Direction.WAIT) append("পরের ${tfLabels[tfIndex]} ক্যান্ডেলের জন্য\n")
            append(r.note).append('\n')
            if (r.candleCount >= 12) {
                append("RSI: ${"%.1f".format(r.rsi)}   MACD hist: ${"%.2f".format(r.macdHist)}\n")
                append("Trend: ${r.trend}   Score: ${r.score}   Candles: ${r.candleCount}\n")
            }
            append("(আনুমানিক সম্ভাবনা — নিশ্চয়তা নয়)")
        }
    }

    /* ---------------- অটো এন্ট্রি ---------------- */

    private fun buyPt(): Pair<Float, Float>? =
        if (prefs.contains("bx")) prefs.getFloat("bx", 0f) to prefs.getFloat("by", 0f) else null

    private fun sellPt(): Pair<Float, Float>? =
        if (prefs.contains("sx")) prefs.getFloat("sx", 0f) to prefs.getFloat("sy", 0f) else null

    private fun toggleAutoEntry() {
        if (!autoEntry) {
            if (buyPt() == null || sellPt() == null) { toast("আগে CALIBRATE করে BUY ও SELL বাটন চিনিয়ে দাও"); return }
            if (TapService.instance == null) { toast("ACCESSIBILITY খুলে S Signal চালু করো"); return }
            autoCount = 0
            autoEntry = true
            toast("AUTO ENTRY চালু। আগে ডেমো অ্যাকাউন্টে পরীক্ষা করো।")
        } else {
            autoEntry = false
        }
        refreshAutoEntryBtn()
    }

    /** পরপর দুটো ট্যাপ নিয়ে BUY ও SELL বাটনের জায়গা সেভ করে */
    private fun calibrate() {
        panelOpen = false
        panel.visibility = View.GONE
        val tv = TextView(this).apply {
            text = "BUY বাটনের উপরে ট্যাপ করো"
            textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#AA000000"))
        }
        var step = 0
        tv.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                if (step == 0) {
                    prefs.edit().putFloat("bx", e.rawX).putFloat("by", e.rawY).apply()
                    step = 1
                    tv.text = "এবার SELL বাটনের উপরে ট্যাপ করো"
                } else {
                    prefs.edit().putFloat("sx", e.rawX).putFloat("sy", e.rawY).apply()
                    try { wm.removeView(tv) } catch (_: Exception) {}
                    toast("BUY ও SELL বাটনের জায়গা সেভ হয়েছে")
                }
            }
            true
        }
        wm.addView(
            tv,
            overlayParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                Gravity.TOP or Gravity.START
            )
        )
    }

    private fun performAutoEntry(r: SignalResult) {
        if (autoCount >= MAX_AUTO_ENTRIES) {
            autoEntry = false
            refreshAutoEntryBtn()
            toast("AUTO ENTRY এর সীমা ($MAX_AUTO_ENTRIES) শেষ — বন্ধ হয়েছে")
            return
        }
        val p = if (r.direction == Direction.CALL) buyPt() else sellPt()
        if (p == null) { toast("আগে CALIBRATE করো"); return }
        val svc = TapService.instance
        if (svc == null) { toast("ACCESSIBILITY চালু নেই"); return }
        panelOpen = false
        panel.visibility = View.GONE            // প্যানেল সরিয়ে দিই যেন ট্যাপ বাটনে পৌঁছায়
        if (svc.tap(p.first, p.second)) {
            autoCount++
            refreshAutoEntryBtn()
            detailText.text = "AUTO ENTRY: ${r.direction}  ($autoCount/$MAX_AUTO_ENTRIES)\n" + detailText.text
        }
    }

    /* ---------------- স্ক্রিন রেকর্ড ---------------- */

    private fun toggleRecord() = if (recording) stopRecord() else startRecord()

    private fun startRecord() {
        try {
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
            val file = File(dir, "S_rec_${System.currentTimeMillis()}.mp4")
            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            rec.setVideoSize(sw, sh)
            rec.setVideoFrameRate(30)
            rec.setVideoEncodingBitRate(6_000_000)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            recDisplay = projection?.createVirtualDisplay(
                "S_rec", sw, sh, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.surface, null, null
            )
            rec.start()
            recorder = rec
            recording = true
            recBtn.text = "■ STOP REC"
            toast("রেকর্ডিং শুরু\n${file.absolutePath}")
        } catch (e: Exception) {
            toast("রেকর্ড শুরু করা যায়নি: ${e.message}")
            releaseRecorder()
        }
    }

    private fun stopRecord() {
        releaseRecorder()
        recBtn.text = "● REC"
        toast("রেকর্ডিং সেভ হয়েছে (Android/data/…/files/Movies)")
    }

    private fun releaseRecorder() {
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recDisplay?.release()
        recorder = null; recDisplay = null; recording = false
    }

    /* ---------------- ক্লিনআপ ---------------- */

    override fun onDestroy() {
        autoSignal = false
        autoEntry = false
        ui.removeCallbacksAndMessages(null)
        releaseRecorder()
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        captureDisplay?.release()
        reader?.close()
        projection?.stop()
        if (::wm.isInitialized) {
            if (::logo.isInitialized) try { wm.removeView(logo) } catch (_: Exception) {}
            if (::panel.isInitialized) try { wm.removeView(panel) } catch (_: Exception) {}
            if (::lines.isInitialized) try { wm.removeView(lines) } catch (_: Exception) {}
            if (::scanView.isInitialized) try { wm.removeView(scanView) } catch (_: Exception) {}
        }
        super.onDestroy()
    }
}
