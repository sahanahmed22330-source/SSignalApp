# Sahan Ai Signal
Live candle analysis overlay: candle movement, size, wicks, patterns, trend, RSI, MACD, Bollinger, Stochastic, support/resistance.
Auto Signal / Auto Entry, result tracking, screen record. Analysis only - no signal is guaranteed.
